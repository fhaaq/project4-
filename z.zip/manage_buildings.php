<?php
session_start();
require_once 'database.php'; // $database

// ── Session Guard ──────────────────────────────────────────────────────────────
if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}
$userName = $_SESSION['name'] ?? 'المسؤول';

$message = '';
$msgType = 'success';

// ── Logic (POST Operations) ───────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // إضافة مبنى
    if ($action === 'add_building') {
        $name     = trim($_POST['building_name']);
        $location = trim($_POST['building_location']);
        $floors   = intval($_POST['total_floors']);
        if ($name) {
            $newId = uniqid('bld_', true);
            // الالتزام ببنية Buildings بحرف كبير
            $database->getReference('Buildings/' . $newId)->set([
                'name'         => $name,
                'location'     => $location,
                'total_floors' => $floors,
                'created_at'   => date('c'),
            ]);
            $message = "تم إضافة المبنى «{$name}» بنجاح ✅";
        }
    }

    // حذف مبنى
    if ($action === 'delete_building') {
        $bid = trim($_POST['building_id']);
        $database->getReference('Buildings/' . $bid)->remove();
        $message = "تم حذف المبنى بنجاح 🗑️";
        $msgType  = 'error';
    }

    // إضافة طابق
    if ($action === 'add_floor') {
        $bid         = trim($_POST['building_id']);
        $floorNumber = intval($_POST['floor_number']);
        $floorName   = trim($_POST['floor_name']);
        $newFloorId  = uniqid('flr_', true);
        $database->getReference('Buildings/' . $bid . '/floors/' . $newFloorId)->set([
            'floor_number' => $floorNumber,
            'name'         => $floorName,
            'created_at'   => date('c'),
        ]);
        $message = "تم إضافة الطابق بنجاح ✅";
    }

    // حذف طابق
    if ($action === 'delete_floor') {
        $bid = trim($_POST['building_id']);
        $fid = trim($_POST['floor_id']);
        $database->getReference('Buildings/' . $bid . '/floors/' . $fid)->remove();
        $message = "تم حذف الطابق 🗑️";
        $msgType  = 'error';
    }
}

// ── Fetch Data (The fix for "Undefined array key") ────────────────────────────
// جلب البيانات من Buildings (بحرف كبير)
// ── Fetch Data (The fix for metadata nesting) ────────────────────────────
$buildingsRaw = $database->getReference('Buildings')->getValue();
$buildings    = [];

if (is_array($buildingsRaw)) {
    foreach ($buildingsRaw as $bid => $bData) {
        if (!is_array($bData)) continue;
        
        // جلب البيانات من داخل عقدة metadata بناءً على هيكلة الفايربيس الجديدة
        $meta = $bData['metadata'] ?? [];
        $bName = $meta['name'] ?? ($bData['name'] ?? 'مبنى بدون اسم'); 
        $bLoc  = $meta['location'] ?? ($bData['location'] ?? '—');

        $floors = [];
        if (!empty($bData['floors']) && is_array($bData['floors'])) {
            foreach ($bData['floors'] as $fid => $fData) {
                $floors[] = [
                    'id'           => $fid,
                    'name'         => $fData['name'] ?? '—',
                    'floor_number' => $fData['floor_number'] ?? 0,
                    'created_at'   => $fData['created_at'] ?? ''
                ];
            }
            usort($floors, fn($a, $b) => $a['floor_number'] <=> $b['floor_number']);
        }

        $buildings[] = [
            'id'       => $bid,
            'name'     => $bName, // تم التوجيه لـ metadata
            'location' => $bLoc,  // تم التوجيه لـ metadata
            'floors'   => $floors
        ];
    }
    usort($buildings, fn($a, $b) => strcmp($a['name'], $b['name']));
}
?>
<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>إدارة المباني — ZeroFootprint</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
<style>
/* التصميم الأصلي كما هو بدون تغيير حرف واحد */
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Cairo',sans-serif;direction:rtl;background:linear-gradient(135deg,#f5f0e6,#e8f5e9);min-height:100vh;}
.navbar{position:fixed;top:0;width:100%;background:#1b5e20;padding:14px 24px;display:flex;justify-content:space-between;align-items:center;color:white;z-index:1000;box-shadow:0 2px 10px rgba(0,0,0,.2);}
.project-name{font-size:22px;font-weight:700;}
.nav-links{display:flex;gap:20px;}
.nav-links a{color:white;text-decoration:none;font-size:15px;opacity:.9;transition:.2s;}
.nav-links a:hover{opacity:1;text-decoration:underline;}
.container{padding-top:90px;max-width:1000px;margin:auto;padding-bottom:40px;padding-left:20px;padding-right:20px;}
h2{color:#1b5e20;margin:24px 0 16px;font-size:24px;}
.alert{padding:12px 18px;border-radius:8px;margin-bottom:20px;font-weight:600;}
.alert.success{background:#c8e6c9;color:#1b5e20;border:1px solid #2e7d32;}
.alert.error{background:#ffcdd2;color:#b71c1c;border:1px solid #e53935;}
.card{background:white;border-radius:14px;box-shadow:0 4px 18px rgba(0,0,0,.1);margin-bottom:24px;overflow:hidden;}
.card-header{background:#2e7d32;color:white;padding:14px 20px;display:flex;justify-content:space-between;align-items:center;}
.card-header h3{font-size:18px;}
.card-body{padding:20px;}
.form-row{display:grid;grid-template-columns:2fr 2fr 1fr auto;gap:12px;align-items:end;margin-bottom:16px;}
.form-row.floor-row{grid-template-columns:1fr 2fr auto;}
input[type=text],input[type=number]{width:100%;padding:9px 12px;border-radius:8px;border:1px solid #ccc;font-family:'Cairo',sans-serif;font-size:14px;}
input:focus{outline:none;border-color:#2e7d32;}
.btn{padding:9px 18px;border:none;border-radius:8px;cursor:pointer;font-family:'Cairo',sans-serif;font-size:14px;font-weight:600;transition:.2s;}
.btn-green{background:#2e7d32;color:white;}
.btn-green:hover{background:#1b5e20;}
.btn-red{background:#e53935;color:white;padding:6px 12px;font-size:13px;}
.btn-red:hover{background:#b71c1c;}
.floors-table{width:100%;border-collapse:collapse;margin-top:12px;}
.floors-table th{background:#e8f5e9;color:#2e7d32;padding:10px;text-align:right;font-size:14px;}
.floors-table td{padding:10px;border-top:1px solid #f0f0f0;font-size:14px;}
.floors-table tr:hover td{background:#fafafa;}
.badge{display:inline-block;background:#e8f5e9;color:#2e7d32;border-radius:20px;padding:2px 10px;font-size:13px;}
.section-divider{border:none;border-top:1px solid #e0e0e0;margin:16px 0;}
label{font-size:14px;font-weight:600;color:#333;display:block;margin-bottom:4px;}
.no-data{text-align:center;color:#888;padding:40px 20px;background:white;border-radius:14px;}
</style>
</head>
<body>
<div class="navbar">
    <div class="project-name">🌿 ZeroFootprint</div>
    <div class="nav-links">
        <a href="dashboard.php">لوحة التحكم</a>
        <a href="manual_entry.php">الإدخال اليدوي</a>
        <a href="logout.php">تسجيل الخروج</a>
    </div>
</div>

<div class="container">
    <h2>🏢 إدارة المباني والطوابق</h2>

    <?php if ($message): ?>
    <div class="alert <?= $msgType ?>"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <!-- Add Building Form -->
    <div class="card">
        <div class="card-header"><h3>➕ إضافة مبنى جديد</h3></div>
        <div class="card-body">
            <form method="POST">
                <input type="hidden" name="action" value="add_building">
                <div class="form-row">
                    <div>
                        <label>اسم المبنى</label>
                        <input type="text" name="building_name" placeholder="المبنى الرئيسي" required>
                    </div>
                    <div>
                        <label>الموقع</label>
                        <input type="text" name="building_location" placeholder="الرياض">
                    </div>
                    <div>
                        <label>عدد الطوابق</label>
                        <input type="number" name="total_floors" value="1" min="1">
                    </div>
                    <div style="display:flex;align-items:flex-end">
                        <button type="submit" class="btn btn-green">إضافة</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Buildings List -->
    <?php foreach ($buildings as $b): ?>
    <div class="card">
        <div class="card-header">
            <h3>🏢 <?= htmlspecialchars($b['name']) ?>
                <span style="font-size:13px;opacity:.8;margin-right:8px">
                    (<?= htmlspecialchars($b['location']) ?>)
                </span>
            </h3>
            <form method="POST" onsubmit="return confirm('حذف المبنى وجميع طوابقه؟')">
                <input type="hidden" name="action" value="delete_building">
                <input type="hidden" name="building_id" value="<?= $b['id'] ?>">
                <button type="submit" class="btn btn-red">🗑️ حذف المبنى</button>
            </form>
        </div>
        <div class="card-body">

            <!-- Floors Table -->
            <?php if (!empty($b['floors'])): ?>
            <table class="floors-table">
                <thead>
                    <tr><th>رقم الطابق</th><th>الاسم</th><th>تاريخ الإضافة</th><th>حذف</th></tr>
                </thead>
                <tbody>
                <?php foreach ($b['floors'] as $f): ?>
                <tr>
                    <td><span class="badge">طابق <?= intval($f['floor_number']) ?></span></td>
                    <td><?= htmlspecialchars($f['name']) ?></td>
                    <td style="font-size:12px;color:#999"><?= substr($f['created_at'], 0, 10) ?></td>
                    <td>
                        <form method="POST" style="display:inline"
                              onsubmit="return confirm('حذف هذا الطابق؟')">
                            <input type="hidden" name="action" value="delete_floor">
                            <input type="hidden" name="building_id" value="<?= $b['id'] ?>">
                            <input type="hidden" name="floor_id" value="<?= $f['id'] ?>">
                            <button type="submit" class="btn btn-red">حذف</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <hr class="section-divider">
            <?php else: ?>
            <p style="color:#888;margin-bottom:12px">لا يوجد طوابق بعد.</p>
            <?php endif; ?>

            <!-- Add Floor Form -->
            <form method="POST">
                <input type="hidden" name="action" value="add_floor">
                <input type="hidden" name="building_id" value="<?= $b['id'] ?>">
                <div class="form-row floor-row">
                    <div>
                        <label>رقم الطابق</label>
                        <input type="number" name="floor_number" placeholder="1" min="0" required>
                    </div>
                    <div>
                        <label>اسم الطابق (اختياري)</label>
                        <input type="text" name="floor_name" placeholder="الأرضي">
                    </div>
                    <div style="display:flex;align-items:flex-end">
                        <button type="submit" class="btn btn-green">+ إضافة طابق</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <?php endforeach; ?>

    <?php if (empty($buildings)): ?>
    <div class="no-data">لا توجد مباني بعد. أضف أول مبنى أعلاه 👆</div>
    <?php endif; ?>
</div>
</body>
</html>
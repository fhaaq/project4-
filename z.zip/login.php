<?php
declare(strict_types=1);
session_start();

// التحقق من الجلسة
if (!empty($_SESSION['uid'])) {
    header('Location: ' . ($_SESSION['role'] === 'admin' ? 'dashboard.php' : 'reports.php'));
    exit;
}

require_once __DIR__ . '/database.php'; 
use Kreait\Firebase\Exception\Auth\FailedToVerifyToken;
use Kreait\Firebase\Exception\AuthException;

// ضع مفتاحك الحقيقي هنا من Firebase Console
define('FIREBASE_WEB_API_KEY', 'AIzaSyA19jYlFk1CfP-Lcqntj_GKiIUFFF1td2o');
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim(filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL) ?? '');
    $password = trim(filter_input(INPUT_POST, 'password', FILTER_DEFAULT) ?? '');

    try {
        $restUrl = 'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=' . FIREBASE_WEB_API_KEY;
        $ch = curl_init($restUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS => json_encode(['email' => $email, 'password' => $password, 'returnSecureToken' => true]),
        ]);
        $body = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

   
        $idToken = $result['idToken'];
        $verifiedToken = $auth->verifyIdToken($idToken);
        $uid = $verifiedToken->claims()->get('sub');

        $snapshot = $database->getReference('users/' . $uid)->getSnapshot();

        if (!$snapshot->exists()) {
            die("Error: UID found in Auth but missing in Realtime Database under: users/$uid");
        }

        $userData = $snapshot->getValue();
        $_SESSION['uid']   = $uid;
        $_SESSION['role']  = $userData['role'] ?? 'user';
        $_SESSION['name']  = $userData['name'] ?? 'مستخدم';
        $_SESSION['email'] = $userData['email'] ?? $email;

        header('Location: ' . ($_SESSION['role'] === 'admin' ? 'dashboard.php' : 'reports.php'));
        exit;

    } catch (Throwable $e) {
        die("<h1>Technical Exception</h1><pre>" . $e->getMessage() . "</pre>");
    }
}
?>
<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>تسجيل الدخول — ZeroFootprint</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;}
body{
    margin:0;font-family:'Cairo',sans-serif;direction:rtl;
    background:linear-gradient(135deg,#f5f0e6,#e8f5e9);
    min-height:100vh;display:flex;flex-direction:column;align-items:center;
    color:#1b5e20;
}
.navbar{
    position:fixed;top:0;width:100%;background:#1b5e20;
    padding:12px 24px;display:flex;justify-content:space-between;align-items:center;
    color:white;z-index:1000;box-shadow:0 2px 10px rgba(0,0,0,.2);
}
.logo-area{display:flex;align-items:center;gap:10px;}
.logo-area img{width:38px;}
.project-name{font-size:21px;font-weight:700;}
.nav-links{display:flex;gap:16px;}
.nav-links a{color:white;text-decoration:none;font-size:15px;padding:6px 12px;border-radius:6px;transition:.2s;}
.nav-links a:hover{background:rgba(255,255,255,.18);}
.form-container{
    margin-top:130px;
    background:rgba(255,255,255,.93);
    backdrop-filter:blur(8px);
    padding:42px 40px;border-radius:18px;
    box-shadow:0 8px 28px rgba(0,0,0,.14);
    width:390px;
}
.form-container h2{text-align:center;margin-bottom:28px;color:#2e7d32;font-size:22px;}
.form-container input{
    width:100%;padding:12px 14px;margin-bottom:14px;
    border-radius:8px;border:1px solid #ccc;font-size:15px;
    font-family:'Cairo',sans-serif;transition:border-color .2s;
}
.form-container input:focus{outline:none;border-color:#2e7d32;box-shadow:0 0 0 3px rgba(46,125,50,.1);}
.form-container button{
    width:100%;padding:13px;background:#2e7d32;color:white;
    border:none;border-radius:8px;font-size:17px;
    font-family:'Cairo',sans-serif;font-weight:700;
    cursor:pointer;transition:background .25s;
}
.form-container button:hover{background:#1b5e20;}
.error-msg{
    background:#ffebee;color:#c62828;border:1px solid #ef9a9a;
    padding:10px 14px;border-radius:8px;margin-bottom:16px;
    text-align:center;font-size:14px;
}
.register-link{text-align:center;margin-top:18px;font-size:14px;color:#555;}
.register-link a{color:#2e7d32;font-weight:700;}
.divider{border:none;border-top:1px solid #e0e0e0;margin:18px 0;}
</style>
</head>
<body>

<div class="navbar">
    <div class="logo-area">
        <img src="logo.png" alt="ZeroFootprint Logo" onerror="this.style.display='none'">
        <div class="project-name">🌿 ZeroFootprint</div>
    </div>
    <div class="nav-links">
        <a href="home.php">الرئيسية</a>
        <a href="about.php">من نحن</a>
        <a href="register.php">إنشاء حساب</a>
    </div>
</div>

<div class="form-container">
    <h2>تسجيل الدخول</h2>

    <?php if ($error): ?>
        <div class="error-msg"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <input
            type="email"
            name="email"
            placeholder="البريد الإلكتروني"
            required
            autocomplete="email"
            value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
        >
        <input
            type="password"
            name="password"
            placeholder="كلمة المرور"
            required
            autocomplete="current-password"
        >
        <button type="submit">دخول ←</button>
    </form>

    <hr class="divider">
    <div class="register-link">
        ليس لديك حساب؟ <a href="register.php">أنشئ حساباً الآن</a>
    </div>
</div>

</body>
</html>
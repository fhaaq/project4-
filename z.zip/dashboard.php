<?php
declare(strict_types=1);
session_start();
require_once 'database.php'; // يفترض وجود متغير $database متصل بـ Firebase

// 1. حماية الجلسة (Session Guard)
if (empty($_SESSION['uid'])) {
    header("Location: login.php");
    exit();
}

$userName = $_SESSION['name'] ?? 'المستخدم';
$role     = $_SESSION['role'] ?? 'user';
$today    = date('Y-m-d');

// تحديد بداية ونهاية اليوم الحالي بصيغة Unix Timestamp (بالثواني)
// ملاحظة: إذا كان تطبيق Flutter يرسل الوقت بالملي ثانية، سنقسم القيمة على 1000 بالأسفل
$todayStart = strtotime(date('Y-m-d 00:00:00'));
$todayEnd   = strtotime(date('Y-m-d 23:59:59'));

// 2. جلب البيانات من مسار المباني الفعلي (Buildings)
$buildingsRaw = $database->getReference('Buildings')->getValue();

// متغيرات التجميع (Aggregates)
$totalElec = 0.0; $totalWater = 0.0; $totalPeople = 0;
$sumTemp = 0.0; $sumHum = 0.0; $sumCO2 = 0.0; 
$count = 0; // لحساب عدد السجلات المطابقة لليوم
$buildingCount = 0; $floorCount = 0;

// 3. معالجة البيانات والفلترة حسب التاريخ
if (is_array($buildingsRaw)) {
    foreach ($buildingsRaw as $bID => $bData) {
        $buildingCount++;
        if (isset($bData['floors']) && is_array($bData['floors'])) {
            foreach ($bData['floors'] as $fID => $fData) {
                $floorCount++;
                $readings = $fData['readings'] ?? null;
                
                if ($readings) {
                    $ts = $readings['timestamp'] ?? 0;
                    
                    // تحويل الملي ثانية إلى ثواني إذا لزم الأمر (إذا كان الرقم يتجاوز 10 خانات)
                    if ($ts > 9999999999) { $ts = (int)($ts / 1000); }

                    // التحقق: هل القراءة تمت خلال اليوم الحالي؟
                    if ($ts >= $todayStart && $ts <= $todayEnd) {
                        $totalElec   += (float)($readings['electricity'] ?? 0);
                        $totalWater  += (float)($readings['water']       ?? 0);
                        $totalPeople += (int)($readings['people']        ?? 0);
                        $sumTemp     += (float)($readings['temperature'] ?? 0);
                        $sumHum      += (float)($readings['humidity']    ?? 0);
                        $sumCO2      += (float)($readings['co2']         ?? 0);
                        $count++;
                    }
                }
            }
        }
    }
}

// حساب المتوسطات فقط إذا وجدت سجلات لليوم
$avgTemp = $count ? round($sumTemp / $count, 1) : 0;
$avgHum  = $count ? round($sumHum  / $count, 1) : 0;
$avgCO2  = $count ? round($sumCO2  / $count, 1) : 0;

// 4. جلب الإعدادات والحدود (Settings/Limits) من المسار الصحيح
$limitsRaw = $database->getReference('settings/limits')->getValue();
$elecLimit = (float)($limitsRaw['electricity'] ?? 1000);
$co2Limit  = (float)($limitsRaw['co2'] ?? 500); // القيمة الافتراضية إذا لم توجد

// 5. تجهيز بيانات الرسم البياني لآخر 7 أيام (تتطلب سجلات تاريخية غير متوفرة حالياً في الهيكلة)
// سنتركها فارغة أو بأصفار حالياً لضمان عدم توقف الصفحة
$chartLabels = [];
for ($i = 6; $i >= 0; $i--) {
    $chartLabels[] = date('Y-m-d', strtotime("-{$i} days"));
}
$chartElec = array_fill(0, 7, 0); 
$chartCO2  = array_fill(0, 7, 0);
?>
<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>لوحة التحكم — ZeroFootprint</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Cairo',sans-serif;direction:rtl;background:linear-gradient(135deg,#f5f0e6,#e8f5e9);min-height:100vh;}
.navbar{position:fixed;top:0;width:100%;background:#1b5e20;padding:14px 24px;display:flex;justify-content:space-between;align-items:center;color:white;z-index:1000;box-shadow:0 2px 10px rgba(0,0,0,.2);}
.project-name{font-size:22px;font-weight:700;}
.nav-links{display:flex;gap:20px;}
.nav-links a{color:white;text-decoration:none;font-size:15px;opacity:.9;transition:.2s;}
.nav-links a:hover{opacity:1;text-decoration:underline;}
.container{padding-top:90px;max-width:1100px;margin:auto;padding-bottom:40px;padding-left:20px;padding-right:20px;}
.welcome{color:#1b5e20;margin:20px 0 24px;font-size:22px;font-weight:700;}
.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:18px;margin-bottom:28px;}
.stat-card{background:white;padding:22px 18px;border-radius:14px;box-shadow:0 4px 16px rgba(0,0,0,.1);text-align:center;transition:transform .2s;}
.stat-card:hover{transform:translateY(-3px);}
.stat-icon{font-size:32px;margin-bottom:8px;}
.stat-label{color:#666;font-size:13px;margin-bottom:6px;}
.stat-value{font-size:28px;font-weight:700;color:#2e7d32;}
.stat-unit{font-size:13px;color:#888;margin-top:2px;}
.stat-card.warn .stat-value{color:#e65100;}
.chart-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:28px;}
.chart-card{background:white;border-radius:14px;padding:22px;box-shadow:0 4px 16px rgba(0,0,0,.1);}
.chart-card h3{color:#2e7d32;margin-bottom:16px;font-size:17px;}
.info-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px;}
.info-card{background:white;border-radius:14px;padding:22px;box-shadow:0 4px 16px rgba(0,0,0,.1);}
.info-card h3{color:#2e7d32;margin-bottom:14px;font-size:17px;}
.info-row{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f0f0f0;font-size:14px;}
.info-row:last-child{border-bottom:none;}
.info-val{font-weight:700;color:#1b5e20;}
.progress-bar{background:#e8f5e9;border-radius:10px;height:8px;margin-top:6px;}
.progress-fill{background:#2e7d32;border-radius:10px;height:8px;transition:width .5s;}
.progress-fill.danger{background:#e53935;}
.date-badge{background:#e8f5e9;color:#2e7d32;border-radius:20px;padding:4px 14px;font-size:13px;font-weight:600;}
@media(max-width:700px){.chart-grid,.info-grid{grid-template-columns:1fr;}}
</style>
</head>
<body>
<div class="navbar">
    <div class="project-name">🌿 ZeroFootprint</div>
    <div class="nav-links">
        <?php if ($role === 'admin'): ?>
        <a href="manage_buildings.php">المباني</a>
        <a href="manual_entry.php">الإدخال</a>
        <a href="settings.php">الإعدادات</a>
        <?php endif; ?>
        <a href="reports.php">التقارير</a>
        <a href="logout.php">تسجيل الخروج</a>
    </div>
</div>

<div class="container">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-top:16px;margin-bottom:8px">
        <div class="welcome">مرحباً، <?= htmlspecialchars($userName) ?> 👋</div>
        <span class="date-badge">📅 <?= date('d/m/Y') ?></span>
    </div>

    <!-- KPI Cards -->
 <div class="stats-grid">
        <!-- الكهرباء -->
        <div class="stat-card <?= ($count > 0 && $totalElec > $elecLimit) ? 'warn' : '' ?>">
            <div class="stat-icon">⚡</div>
            <div class="stat-label">إجمالي الكهرباء اليوم</div>
            <div class="stat-value"><?= ($count > 0) ? number_format($totalElec, 1) : '—' ?></div>
            <div class="stat-unit">kWh</div>
        </div>

        <!-- المياه -->
        <div class="stat-card">
            <div class="stat-icon">💧</div>
            <div class="stat-label">إجمالي المياه اليوم</div>
            <div class="stat-value"><?= ($count > 0) ? number_format($totalWater, 1) : '—' ?></div>
            <div class="stat-unit">لتر</div>
        </div>

        <!-- الحرارة -->
        <div class="stat-card">
            <div class="stat-icon">🌡️</div>
            <div class="stat-label">متوسط الحرارة</div>
            <div class="stat-value"><?= ($count > 0) ? $avgTemp : '—' ?></div>
            <div class="stat-unit">°C</div>
        </div>

        <!-- الرطوبة -->
        <div class="stat-card">
            <div class="stat-icon">💦</div>
            <div class="stat-label">متوسط الرطوبة</div>
            <div class="stat-value"><?= ($count > 0) ? $avgHum : '—' ?></div>
            <div class="stat-unit">%</div>
        </div>

        <!-- ثاني أكسيد الكربون -->
        <div class="stat-card <?= ($count > 0 && $avgCO2 > $co2Limit) ? 'warn' : '' ?>">
            <div class="stat-icon">☁️</div>
            <div class="stat-label">متوسط CO₂</div>
            <div class="stat-value"><?= ($count > 0) ? $avgCO2 : '—' ?></div>
            <div class="stat-unit">ppm</div>
        </div>

        <!-- المباني والطوابق (تظهر دائماً لأنها هيكلية وليست قراءات يومية) -->
        <div class="stat-card">
            <div class="stat-icon">🏢</div>
            <div class="stat-label">المباني / الطوابق</div>
            <div class="stat-value"><?= $buildingCount ?><span style="font-size:16px;color:#888"> / <?= $floorCount ?></span></div>
            <div class="stat-unit">مبنى / طابق</div>
        </div>
    </div>

    <!-- Charts -->
    <div class="chart-grid">
        <div class="chart-card">
            <h3>⚡ استهلاك الكهرباء — آخر 7 أيام</h3>
            <canvas id="elecChart" height="200"></canvas>
        </div>
        <div class="chart-card">
            <h3>☁️ مستوى CO₂ — آخر 7 أيام</h3>
            <canvas id="co2Chart" height="200"></canvas>
        </div>
    </div>

    <!-- Progress + Summary -->
    <div class="info-grid">
        <div class="info-card">
            <h3>📊 مؤشرات الاستهلاك مقابل الحدود</h3>
            <?php
            // حساب النسب المئوية فقط في حال وجود بيانات لتجنب القسمة على صفر أو عرض نسب خاطئة
            $elecPct = ($count > 0 && $elecLimit > 0) ? min(100, round($totalElec / $elecLimit * 100)) : 0;
            $co2Pct  = ($count > 0 && $co2Limit > 0)  ? min(100, round($avgCO2   / $co2Limit  * 100)) : 0;
            ?>
            <div class="info-row">
                <span>الكهرباء (<?= ($count > 0) ? $totalElec : 0 ?> / <?= $elecLimit ?> kWh)</span>
                <span class="info-val"><?= $elecPct ?>%</span>
            </div>
            <div class="progress-bar">
                <div class="progress-fill <?= $elecPct >= 90 ? 'danger' : '' ?>"
                     style="width:<?= $elecPct ?>%"></div>
            </div>
            
            <div class="info-row" style="margin-top:14px">
                <span>CO₂ (<?= ($count > 0) ? $avgCO2 : 0 ?> / <?= $co2Limit ?> ppm)</span>
                <span class="info-val"><?= $co2Pct ?>%</span>
            </div>
            <div class="progress-bar">
                <div class="progress-fill <?= $co2Pct >= 90 ? 'danger' : '' ?>"
                     style="width:<?= $co2Pct ?>%"></div>
            </div>
        </div>

        <div class="info-card">
            <h3>ℹ️ ملخص اليوم</h3>
            <div class="info-row"><span>التاريخ</span><span class="info-val"><?= $today ?></span></div>
            <div class="info-row"><span>سجلات اليوم</span><span class="info-val"><?= $count ?></span></div>
            <div class="info-row"><span>إجمالي المباني</span><span class="info-val"><?= $buildingCount ?></span></div>
            <div class="info-row"><span>إجمالي الطوابق</span><span class="info-val"><?= $floorCount ?></span></div>
            <div class="info-row"><span>المستخدم</span><span class="info-val"><?= htmlspecialchars($userName) ?></span></div>
            <div class="info-row"><span>الصلاحية</span>
                <span class="info-val"><?= $role === 'admin' ? '👑 مسؤول' : '👤 مستخدم' ?></span>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const labels   = <?= json_encode(array_values($chartLabels)) ?>;
const elecData = <?= json_encode(array_values($chartElec))   ?>;
const co2Data  = <?= json_encode(array_values($chartCO2))    ?>;

const baseOpts = {
    responsive: true,
    plugins: { legend: { display: false } },
    scales: {
        x: { grid: { display: false } },
        y: { beginAtZero: true, grid: { color: '#f0f0f0' } }
    }
};

new Chart(document.getElementById('elecChart'), {
    type: 'bar',
    data: { labels, datasets: [{ data: elecData, backgroundColor: '#2e7d32', borderRadius: 6 }] },
    options: baseOpts
});

new Chart(document.getElementById('co2Chart'), {
    type: 'line',
    data: { labels, datasets: [{
        data: co2Data, borderColor: '#1b5e20',
        backgroundColor: 'rgba(46,125,50,.15)',
        fill: true, tension: 0.4, pointRadius: 4
    }]},
    options: baseOpts
});
</script>
</body>
</html>
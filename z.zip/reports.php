<?php
session_start();
require_once 'database.php'; // $database

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

$role = $_SESSION['role'] ?? 'viewer';

// ── الفلاتر الافتراضية (آخر 7 أيام) ──────────────────────────────────────────
$fromDate = $_GET['from_date'] ?? date('Y-m-d', strtotime('-7 days'));
$toDate   = $_GET['to_date']   ?? date('Y-m-d');
$selBldg  = $_GET['building_id'] ?? '';

// ── جلب قائمة المباني ────────────────────────────────────────────────────────
$buildingsRaw = $database->getReference('Buildings')->getValue();
$buildingsList = [];
if (is_array($buildingsRaw)) {
    foreach ($buildingsRaw as $id => $data) {
        $buildingsList[] = ['id' => $id, 'name' => $data['metadata']['name'] ?? $id];
    }
}

// ── جلب وتصفية البيانات ──────────────────────────────────────────────────────
$allData = [];
$totalElec = 0; $totalWater = 0; $sumTemp = 0; $sumHum = 0; $sumCO2 = 0; $recCount = 0;
$byDay = [];

if (is_array($buildingsRaw)) {
    foreach ($buildingsRaw as $bid => $bData) {
        // إذا تم اختيار مبنى معين، نتخطى البقية
        if ($selBldg && $bid !== $selBldg) continue;

        if (isset($bData['floors']) && is_array($bData['floors'])) {
            foreach ($bData['floors'] as $fid => $fData) {
                // ملاحظة: افترضنا هنا أن التاريخ مخزن في عقدة history داخل كل طابق
                // إذا كان المسار مختلفاً في قاعدتك، يرجى تعديل 'history' للمسار الصحيح
                $history = $fData['history'] ?? ($fData['readings'] ?? []); 
                
                // تحويل البيانات لمصفوفة إذا كانت سجلاً واحداً
                $records = isset($history['timestamp']) ? [$history] : $history;

                if (is_array($records)) {
                    foreach ($records as $r) {
                        if (!isset($r['timestamp'])) continue;
                        
                        $rDate = date('Y-m-d', $r['timestamp']);
                        
                        // التحقق من نطاق التاريخ
                        if ($rDate >= $fromDate && $rDate <= $toDate) {
                            $elec  = floatval($r['electricity'] ?? 0);
                            $water = floatval($r['water'] ?? 0);
                            $co2   = floatval($r['co2'] ?? 0);
                            $temp  = floatval($r['temperature'] ?? 0);
                            $hum   = floatval($r['humidity'] ?? 0);

                            // تجميع البيانات حسب اليوم للرسم البياني
                            if (!isset($byDay[$rDate])) {
                                $byDay[$rDate] = ['elec'=>0, 'water'=>0, 'co2'=>0, 'count'=>0];
                            }
                            $byDay[$rDate]['elec']  += $elec;
                            $byDay[$rDate]['water'] += $water;
                            $byDay[$rDate]['co2']   = max($byDay[$rDate]['co2'], $co2);
                            $byDay[$rDate]['count']++;

                            // حساب الإجماليات للـ KPIs
                            $totalElec  += $elec;
                            $totalWater += $water;
                            $sumTemp    += $temp;
                            $sumHum     += $hum;
                            $sumCO2     += $co2;
                            $recCount++;
                        }
                    }
                }
            }
        }
    }
}

ksort($byDay); // ترتيب الأيام تصاعدياً

$avgTemp = $recCount ? round($sumTemp / $recCount, 1) : 0;
$avgHum  = $recCount ? round($sumHum  / $recCount, 1) : 0;
$avgCO2  = $recCount ? round($sumCO2  / $recCount, 1) : 0;

// تجهيز بيانات التشارت
$chartLabels = array_keys($byDay);
$chartElec   = array_column($byDay, 'elec');
$chartWater  = array_column($byDay, 'water');
$chartCO2    = array_column($byDay, 'co2');
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>التقارير المتقدمة — ZeroFootprint</title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        /* التنسيقات (نفس الستايل الذي تفضله) */
        *{box-sizing:border-box;margin:0;padding:0}
        body{font-family:'Cairo',sans-serif;background:#f4f7f6;color:#333;line-height:1.6}
        .navbar{background:#1b5e20;padding:1rem 2rem;display:flex;justify-content:space-between;align-items:center;color:white;box-shadow:0 2px 10px rgba(0,0,0,.1)}
        .navbar a{color:white;text-decoration:none;margin-right:15px;font-size:0.9rem}
        .container{max-width:1200px;margin:20px auto;padding:0 20px}
        .filter-card{background:white;padding:20px;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,.05);margin-bottom:25px}
        .filter-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:15px;align-items:end}
        label{display:block;font-size:0.8rem;margin-bottom:5px;color:#666}
        select, input{width:100%;padding:10px;border:1px solid #ddd;border-radius:8px;font-family:inherit}
        .btn-search{background:#2e7d32;color:white;border:none;padding:10px;border-radius:8px;cursor:pointer;font-weight:600}
        .kpi-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:15px;margin-bottom:25px}
        .kpi-card{background:white;padding:20px;border-radius:12px;text-align:center;box-shadow:0 2px 10px rgba(0,0,0,.05)}
        .kpi-card .val{display:block;font-size:1.8rem;font-weight:700;color:#2e7d32}
        .kpi-card .label{font-size:0.75rem;color:#888}
        .chart-container{background:white;padding:20px;border-radius:12px;box-shadow:0 2px 10px rgba(0,0,0,.05);margin-bottom:25px}
        table{width:100%;border-collapse:collapse;background:white;border-radius:12px;overflow:hidden}
        th{background:#f8faf9;padding:15px;text-align:right;font-size:0.85rem;color:#555}
        td{padding:15px;border-top:1px solid #eee;font-size:0.85rem}
    </style>
</head>
<body>

<div class="navbar">
    <div style="font-weight:700;font-size:1.2rem">🌿 ZeroFootprint</div>
    <div>
        <a href="dashboard.php">الرئيسية</a>
        <a href="settings.php">الإعدادات</a>
        <a href="logout.php">خروج</a>
    </div>
</div>

<div class="container">
    <div class="filter-card">
        <form method="GET" class="filter-grid">
            <div>
                <label>المبنى</label>
                <select name="building_id">
                    <option value="">كل المباني</option>
                    <?php foreach($buildingsList as $b): ?>
                        <option value="<?= $b['id'] ?>" <?= $selBldg == $b['id'] ? 'selected' : '' ?>><?= htmlspecialchars($b['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label>من تاريخ</label>
                <input type="date" name="from_date" value="<?= $fromDate ?>">
            </div>
            <div>
                <label>إلى تاريخ</label>
                <input type="date" name="to_date" value="<?= $toDate ?>">
            </div>
            <button type="submit" class="btn-search">🔍 تحديث التقارير</button>
        </form>
    </div>

    <div class="kpi-grid">
        <div class="kpi-card"><span class="label">إجمالي الكهرباء</span><span class="val"><?= number_format($totalElec,1) ?></span><small>kWh</small></div>
        <div class="kpi-card"><span class="label">إجمالي المياه</span><span class="val"><?= number_format($totalWater,1) ?></span><small>Litre</small></div>
        <div class="kpi-card"><span class="label">متوسط الحرارة</span><span class="val"><?= $avgTemp ?></span><small>°C</small></div>
        <div class="kpi-card"><span class="label">متوسط CO₂</span><span class="val"><?= $avgCO2 ?></span><small>ppm</small></div>
    </div>

    <?php if ($recCount > 0): ?>
    <div class="chart-container">
        <canvas id="mainChart" style="max-height: 400px;"></canvas>
    </div>

    <table>
        <thead>
            <tr>
                <th>التاريخ</th>
                <th>الكهرباء (kWh)</th>
                <th>المياه (لتر)</th>
                <th>أعلى CO₂ سجل</th>
                <th>عدد القراءات</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($byDay as $day => $data): ?>
            <tr>
                <td><?= $day ?></td>
                <td><?= number_format($data['elec'], 2) ?></td>
                <td><?= number_format($data['water'], 2) ?></td>
                <td><?= $data['co2'] ?></td>
                <td><?= $data['count'] ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: ?>
        <div style="text-align:center; padding:50px; background:white; border-radius:12px;">لا توجد بيانات لهذه الفترة 🔍</div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctx = document.getElementById('mainChart').getContext('2d');
new Chart(ctx, {
    type: 'line',
    data: {
        labels: <?= json_encode($chartLabels) ?>,
        datasets: [{
            label: 'الكهرباء (kWh)',
            data: <?= json_encode($chartElec) ?>,
            borderColor: '#2e7d32',
            backgroundColor: 'rgba(46, 125, 50, 0.1)',
            fill: true,
            tension: 0.4
        }, {
            label: 'المياه (Litre)',
            data: <?= json_encode($chartWater) ?>,
            borderColor: '#0288d1',
            backgroundColor: 'transparent',
            borderDash: [5, 5],
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { position: 'bottom' } },
        scales: { y: { beginAtZero: true } }
    }
});
</script>
</body>
</html>
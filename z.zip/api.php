<?php
/**
 * api.php — REST API endpoint → Firebase Realtime Database
 * Actions: save_reading | get_floor | list_floors
 */
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

$body = [];
$raw  = file_get_contents('php://input');
if ($raw !== '' && str_contains($_SERVER['CONTENT_TYPE'] ?? '', 'application/json')) {
    $body = json_decode($raw, true) ?? [];
}

function param(string $key, mixed $default = null): mixed
{
    global $body;
    return $body[$key] ?? $_POST[$key] ?? $_GET[$key] ?? $default;
}

try {
    require_once __DIR__ . '/database.php'; // $database
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Firebase init failed', 'detail' => $e->getMessage()]);
    exit;
}

$today  = date('Y-m-d');
$action = param('action', '');

// Sanitize key for RTDB (no . # $ / [ ])
function rtdbKey(string $raw): string {
    return str_replace(['.', '#', '$', '/', '[', ']'], '_', $raw);
}

try {
    match ($action) {

        // ── save_reading ──────────────────────────────────────────────────────
        'save_reading' => (static function () use ($database, $today): void {
            $floorId     = trim((string) param('floor_id', ''));
            $temp        = param('temp')        !== null ? (float) param('temp')        : null;
            $humidity    = param('humidity')    !== null ? (float) param('humidity')    : null;
            $co2         = param('co2')         !== null ? (float) param('co2')         : null;
            $electricity = param('electricity') !== null ? (float) param('electricity') : null;
            $water       = param('water')       !== null ? (float) param('water')       : null;

            if ($floorId === '') {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'floor_id is required']);
                return;
            }

            $docKey = rtdbKey($floorId) . '_' . $today;

            $payload = ['floor_id' => $floorId, 'record_date' => $today, 'last_updated' => date('c')];
            if ($temp        !== null) $payload['avg_temperature']   = $temp;
            if ($humidity    !== null) $payload['avg_humidity']       = $humidity;
            if ($co2         !== null) $payload['avg_co2']            = $co2;
            if ($electricity !== null) $payload['total_electricity']  = $electricity;
            if ($water       !== null) $payload['total_water']        = $water;

            // update() = merge/patch — preserves fields not in $payload
            $database->getReference('daily_records/' . $docKey)->update($payload);

            http_response_code(200);
            echo json_encode(['success' => true, 'message' => 'Reading saved', 'data' => $payload]);
        })(),

        // ── get_floor ─────────────────────────────────────────────────────────
        'get_floor' => (static function () use ($database, $today): void {
            $floorId = trim((string) param('floor_id', ''));
            $date    = trim((string) param('date', $today));

            if ($floorId === '') {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'floor_id is required']);
                return;
            }

            $docKey = rtdbKey($floorId) . '_' . $date;
            $value  = $database->getReference('daily_records/' . $docKey)->getValue();

            if ($value === null) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'No record found for this floor/date']);
                return;
            }

            http_response_code(200);
            echo json_encode(['success' => true, 'data' => $value]);
        })(),

        // ── list_floors ───────────────────────────────────────────────────────
        'list_floors' => (static function () use ($database, $today): void {
            $date = trim((string) param('date', $today));

            // Fetch buildings tree to get floor metadata
            $buildingsRaw = $database->getReference('buildings')->getValue();
            // Fetch all records, filter by date
            $allRecords   = $database->getReference('daily_records')->getValue();

            // Index records by floor_id for fast lookup
            $recByFloor = [];
            if (is_array($allRecords)) {
                foreach ($allRecords as $key => $rec) {
                    if (is_array($rec) && ($rec['record_date'] ?? '') === $date) {
                        $recByFloor[$rec['floor_id'] ?? ''] = $rec;
                    }
                }
            }

            $floors = [];
            if (is_array($buildingsRaw)) {
                foreach ($buildingsRaw as $bid => $bData) {
                    if (!is_array($bData) || empty($bData['floors'])) continue;
                    foreach ($bData['floors'] as $fid => $fData) {
                        $rec  = $recByFloor[$fid] ?? [];
                        $elec = (float) ($rec['total_electricity'] ?? 0);
                        $wat  = (float) ($rec['total_water']       ?? 0);
                        $floors[] = [
                            'floor_id'          => $fid,
                            'floor_number'      => $fData['floor_number']  ?? null,
                            'building_name'     => $bData['name']          ?? null,
                            'total_electricity' => $elec,
                            'total_water'       => $wat,
                            'avg_temperature'   => $rec['avg_temperature'] ?? null,
                            'avg_humidity'      => $rec['avg_humidity']    ?? null,
                            'avg_co2'           => $rec['avg_co2']         ?? null,
                            'carbon_footprint'  => round($elec * 0.5 + $wat * 0.0003, 4),
                        ];
                    }
                }
            }

            http_response_code(200);
            echo json_encode(['success' => true, 'date' => $date, 'floors' => $floors]);
        })(),

        default => (static function () use ($action): void {
            http_response_code(400);
            echo json_encode([
                'success'           => false,
                'error'             => 'Unknown action: ' . htmlspecialchars($action),
                'available_actions' => ['save_reading', 'get_floor', 'list_floors'],
            ]);
        })(),
    };

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Server error', 'detail' => $e->getMessage()]);
}
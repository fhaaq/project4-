<?php
session_start();
require_once 'database.php'; // يفترض وجود اتصالك بـ $database هنا

// ── Session Guard ──────────────────────────────────────────────────────────────
if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$userName = $_SESSION['name'] ?? 'المسؤول';
$today    = date('Y-m-d');
$messages = [];

// ── دالة تحويل الأرقام لضمان الصيغة الإنجليزية قبل الإرسال للفايربيس ──────────────
function convertToEnglishNumbers($str) {
    $arabic  = ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
    $persian = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    $english = ['0','1','2','3','4','5','6','7','8','9'];
    $str = str_replace($arabic, $english, $str);
    return str_replace($persian, $english, $str);
}

// ── Handle POST (Saving to Buildings/{id}/floors/{id}/readings) ──────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_floor'])) {
    $buildingId  = trim($_POST['building_id']);
    $floorId     = trim($_POST['floor_id']);
    
    // تحويل المدخلات لأرقام إنجليزية ثم معالجتها حسابياً[cite: 6]
    $electricity = floatval(convertToEnglishNumbers($_POST['electricity']));
    $people      = intval(convertToEnglishNumbers($_POST['people']));
    $temperature = floatval(convertToEnglishNumbers($_POST['temperature']));
    $humidity    = floatval(convertToEnglishNumbers($_POST['humidity']));
    $water       = floatval(convertToEnglishNumbers($_POST['water']));

    // معادلة حساب CO2 المعتمدة[cite: 6]
    $co2 = round(($electricity * 0.5) + ($water * 0.0003) + ($people * 0.01), 2);

    // المسار المعتمد حسب بنية الفايربيس الخاصة بك[cite: 5, 6]
    $path = "Buildings/{$buildingId}/floors/{$floorId}/readings";

    $database->getReference($path)->set([
        'co2'         => $co2,
        'electricity' => $electricity,
        'humidity'    => $humidity,
        'people'      => $people,
        'temperature' => $temperature,
        'water'       => $water,
        'timestamp'   => time() // حفظ بنظام Unix Timestamp[cite: 5]
    ]);

    $messages[] = "تم تحديث بيانات الطابق بنجاح ✅ (CO₂: {$co2})";
}

// ── جلب البيانات مع دعم الـ metadata والمسار الصحيح ─────────────────────────────
$buildingsRaw = $database->getReference('Buildings')->getValue();
$buildings    = [];

if (is_array($buildingsRaw)) {
    foreach ($buildingsRaw as $bid => $bData) {
        if (!is_array($bData)) continue;
        
        // جلب الاسم والموقع من metadata لضمان عدم ظهور "بدون اسم"[cite: 5]
        $meta  = $bData['metadata'] ?? [];
        $bName = $meta['name'] ?? ($bData['name'] ?? 'مبنى بدون اسم');
        $bLoc  = $meta['location'] ?? ($bData['location'] ?? '');

        $floors = [];
        if (!empty($bData['floors']) && is_array($bData['floors'])) {
            foreach ($bData['floors'] as $fid => $fData) {
                $floors[] = [
                    'id'           => $fid,
                    'name'         => $fData['name'] ?? '',
                    'floor_number' => $fData['floor_number'] ?? 0,
                    'readings'     => $fData['readings'] ?? []
                ];
            }
            // ترتيب الطوابق
            usort($floors, fn($a, $b) => ($a['floor_number'] <=> $b['floor_number']));
        }
        
        $buildings[] = [
            'id'       => $bid, 
            'name'     => $bName, 
            'location' => $bLoc, 
            'floors'   => $floors
        ];
    }
    // ترتيب المباني أبجدياً
    usort($buildings, fn($a, $b) => strcmp($a['name'], $b['name']));
}
?>
<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>الإدخال اليدوي — ZeroFootprint</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
<style>
/* CSS الأصلي بدون أي تعديل[cite: 6] */
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Cairo',sans-serif;direction:rtl;background:linear-gradient(135deg,#f5f0e6,#e8f5e9);min-height:100vh;}
.navbar{position:fixed;top:0;width:100%;background:#1b5e20;padding:14px 24px;display:flex;justify-content:space-between;align-items:center;color:white;z-index:1000;box-shadow:0 2px 10px rgba(0,0,0,.2);}
.project-name{font-size:22px;font-weight:700;}
.nav-links{display:flex;gap:20px;}
.nav-links a{color:white;text-decoration:none;font-size:15px;opacity:.9;}
.nav-links a:hover{opacity:1;text-decoration:underline;}
.container{padding-top:90px;max-width:950px;margin:auto;padding-bottom:40px;padding-left:20px;padding-right:20px;}
h2{color:#1b5e20;margin:20px 0;font-size:23px;}
.alert{padding:12px 18px;border-radius:8px;margin-bottom:16px;font-weight:600;background:#c8e6c9;color:#1b5e20;border:1px solid #2e7d32;}
.building-header{background:#2e7d32;color:white;border-radius:12px 12px 0 0;padding:14px 20px;font-size:17px;font-weight:700;margin-top:20px;}
.floor-card{background:white;padding:20px;box-shadow:0 2px 8px rgba(0,0,0,.08);border-bottom:1px solid #e0e0e0;}
.floor-card:last-child{border-radius:0 0 12px 12px;border-bottom:none;}
.floor-title{font-size:15px;font-weight:700;color:#2e7d32;margin-bottom:14px;display:flex;align-items:center;gap:8px;}
.floor-title .badge{background:#e8f5e9;border-radius:20px;padding:3px 12px;font-size:13px;}
.form-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-bottom:14px;}
.form-group label{font-size:12px;font-weight:600;color:#555;display:block;margin-bottom:4px;}
.form-group input{width:100%;padding:9px 12px;border-radius:8px;border:1px solid #ccc;font-family:'Cairo',sans-serif;font-size:14px;}
.form-group input:focus{outline:none;border-color:#2e7d32;}
.btn-save{padding:9px 24px;background:#2e7d32;color:white;border:none;border-radius:8px;cursor:pointer;font-family:'Cairo',sans-serif;font-size:14px;font-weight:600;transition:.2s;}
.btn-save:hover{background:#1b5e20;}
.saved-badge{display:inline-block;background:#e8f5e9;color:#2e7d32;border-radius:20px;padding:3px 12px;font-size:12px;}
.co2-note{font-size:11px;color:#888;margin-top:6px;}
.no-data{text-align:center;color:#888;padding:60px 20px;background:white;border-radius:14px;}
</style>
</head>
<body>
<div class="navbar">
    <div class="project-name">🌿 ZeroFootprint — مرحباً، <?= htmlspecialchars($userName) ?></div>
    <div class="nav-links">
        <a href="dashboard.php">لوحة التحكم</a>
        <a href="manage_buildings.php">المباني</a>
        <a href="logout.php">تسجيل الخروج</a>
    </div>
</div>

<div class="container">
    <h2>✏️ الإدخال اليدوي للقراءات</h2>

    <?php foreach ($messages as $msg): ?>
    <div class="alert"><?= htmlspecialchars($msg) ?></div>
    <?php endforeach; ?>

    <?php if (empty($buildings)): ?>
    <div class="no-data">لا توجد مباني مسجلة. <a href="manage_buildings.php" style="color:#2e7d32">أضف مبنى أولاً</a></div>
    <?php endif; ?>

    <?php foreach ($buildings as $b): ?>
    <div class="building-header">
        🏢 <?= htmlspecialchars($b['name']) ?>
        <span style="font-size:13px;opacity:.8"><?= htmlspecialchars($b['location']) ?></span>
    </div>

    <?php if (empty($b['floors'])): ?>
    <div class="floor-card" style="color:#888;border-radius:0 0 12px 12px">لا توجد طوابق لهذا المبنى.</div>
    <?php endif; ?>

    <?php foreach ($b['floors'] as $f): 
        $r = $f['readings']; 
    ?>
    <div class="floor-card">
        <div class="floor-title">
            <span class="badge">طابق <?= intval($f['floor_number']) ?></span>
            <?= htmlspecialchars($f['name']) ?>
            <?php if (!empty($r)): ?>
            <span class="saved-badge">📊 توجد قراءات حالية</span>
            <?php endif; ?>
        </div>

        <form method="POST">
            <input type="hidden" name="building_id" value="<?= $b['id'] ?>">
            <input type="hidden" name="floor_id"    value="<?= $f['id'] ?>">

            <div class="form-grid">
                <div class="form-group">
                    <label>⚡ الكهرباء (kWh)</label>
                    <input type="text" name="electricity" lang="en" dir="ltr"
                           value="<?= htmlspecialchars((string)($r['electricity'] ?? '')) ?>" 
                           placeholder="0.00" required>
                </div>
                <div class="form-group">
                    <label>👤 عدد الأشخاص</label>
                    <input type="text" name="people" lang="en" dir="ltr"
                           value="<?= htmlspecialchars((string)($r['people'] ?? '')) ?>" 
                           placeholder="0" required>
                </div>
                <div class="form-group">
                    <label>🌡️ درجة الحرارة (°C)</label>
                    <input type="text" name="temperature" lang="en" dir="ltr"
                           value="<?= htmlspecialchars((string)($r['temperature'] ?? '')) ?>" 
                           placeholder="25.0" required>
                </div>
                <div class="form-group">
                    <label>💦 الرطوبة (%)</label>
                    <input type="text" name="humidity" lang="en" dir="ltr"
                           value="<?= htmlspecialchars((string)($r['humidity'] ?? '')) ?>" 
                           placeholder="50.0" required>
                </div>
                <div class="form-group">
                    <label>💧 المياه (لتر)</label>
                    <input type="text" name="water" lang="en" dir="ltr"
                           value="<?= htmlspecialchars((string)($r['water'] ?? '')) ?>" 
                           placeholder="0.00" required>
                </div>
            </div>
            <p class="co2-note">* سيتم حساب انبعاثات الكربون تلقائياً عند الحفظ.</p>
            <button type="submit" name="submit_floor" class="btn-save">💾 حفظ وتحديث القراءات</button>
        </form>
    </div>
    <?php endforeach; ?>
    <?php endforeach; ?>
</div>
</body>
</html>
<?php
/**
 * register.php — Firebase Auth + Realtime Database
 * Creates user in Auth, then writes profile to /users/{uid}
 */
declare(strict_types=1);

require_once __DIR__ . '/database.php'; // $auth, $database

use Kreait\Firebase\Exception\Auth\EmailAlreadyExists;
use Kreait\Firebase\Exception\AuthException;
use Kreait\Firebase\Auth\CreateUser;

$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name     = trim(filter_input(INPUT_POST, 'name',     FILTER_DEFAULT)        ?? '');
    $email    = trim(filter_input(INPUT_POST, 'email',    FILTER_SANITIZE_EMAIL) ?? '');
    $password = trim(filter_input(INPUT_POST, 'password', FILTER_DEFAULT)        ?? '');
    $role     = trim(filter_input(INPUT_POST, 'role',     FILTER_DEFAULT)        ?? 'user');

    $allowedRoles = ['user', 'admin'];
    if (!in_array($role, $allowedRoles, true)) $role = 'user';

    if ($name === '' || $email === '' || $password === '') {
        $error = 'يرجى ملء جميع الحقول.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'صيغة البريد الإلكتروني غير صحيحة.';
    } elseif (strlen($password) < 8) {
        $error = 'كلمة المرور يجب أن تكون 8 أحرف على الأقل.';
    } else {
        try {
    // 1. إنشاء المستخدم في Firebase Auth باستخدام المصفوفة (الأضمن)
    $createdUser = $auth->createUser([
        'email' => $email,
        'clearTextPassword' => $password,
        'displayName' => $name,
    ]);
    
    $uid = $createdUser->uid;

    // 2. توحيد الهيكلية مع تطبيق Flutter
    // تأكد أن أسماء الحقول (role, email, name) هي نفس المستخدمة في كود Flutter
    $database->getReference('users/' . $uid)->set([
        'uid'       => $uid,
        'name'      => $name,
        'email'     => $email,
        'role'      => $role, // 'admin' أو 'user'
        'createdAt' => date('c'), // تنسيق ISO 8601 وهو المفضل في Flutter
        'selectedBuildingID' => null, // حقل إضافي لضمان عدم حدوث Null Crash في التطبيق
    ]);

    $success = 'تم إنشاء الحساب بنجاح! سيتم تحويلك الآن...';
    header('Refresh: 2; URL=login.php');

} catch (\Kreait\Firebase\Exception\Auth\EmailAlreadyExists $e) {
    $error = 'هذا البريد الإلكتروني مسجل مسبقاً.';
} catch (Throwable $e) {
    $error = 'خطأ أثناء التسجيل: ' . $e->getMessage();
}
    }
}
?>
<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>إنشاء حساب — ZeroFootprint</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;}
body{margin:0;font-family:'Cairo',sans-serif;direction:rtl;background:linear-gradient(135deg,#f5f0e6,#e8f5e9);min-height:100vh;display:flex;flex-direction:column;align-items:center;color:#1b5e20;}
.navbar{position:fixed;top:0;width:100%;background:#1b5e20;padding:12px 24px;display:flex;justify-content:space-between;align-items:center;color:white;z-index:1000;box-shadow:0 2px 10px rgba(0,0,0,.2);}
.logo-area{display:flex;align-items:center;gap:10px;}
.logo-area img{width:38px;}
.project-name{font-size:21px;font-weight:700;}
.nav-links{display:flex;gap:16px;}
.nav-links a{color:white;text-decoration:none;font-size:15px;padding:6px 12px;border-radius:6px;transition:.2s;}
.nav-links a:hover{background:rgba(255,255,255,.18);}
.form-container{margin-top:130px;background:rgba(255,255,255,.93);backdrop-filter:blur(8px);padding:42px 40px;border-radius:18px;box-shadow:0 8px 28px rgba(0,0,0,.14);width:390px;}
.form-container h2{text-align:center;margin-bottom:28px;color:#2e7d32;font-size:22px;}
.form-container input,.form-container select{width:100%;padding:12px 14px;margin-bottom:14px;border-radius:8px;border:1px solid #ccc;font-size:15px;font-family:'Cairo',sans-serif;transition:border-color .2s;background:white;}
.form-container input:focus,.form-container select:focus{outline:none;border-color:#2e7d32;box-shadow:0 0 0 3px rgba(46,125,50,.1);}
.form-container button{width:100%;padding:13px;background:#2e7d32;color:white;border:none;border-radius:8px;font-size:17px;font-family:'Cairo',sans-serif;font-weight:700;cursor:pointer;transition:background .25s;}
.form-container button:hover{background:#1b5e20;}
.error-msg{background:#ffebee;color:#c62828;border:1px solid #ef9a9a;padding:10px 14px;border-radius:8px;margin-bottom:16px;text-align:center;font-size:14px;}
.success-msg{background:#e8f5e9;color:#2e7d32;border:1px solid #a5d6a7;padding:10px 14px;border-radius:8px;margin-bottom:16px;text-align:center;font-size:14px;}
.login-link{text-align:center;margin-top:18px;font-size:14px;color:#555;}
.login-link a{color:#2e7d32;font-weight:700;}
</style>
</head>
<body>
<div class="navbar">
    <div class="logo-area">
        <img src="logo.png" alt="logo" onerror="this.style.display='none'">
        <div class="project-name">🌿 ZeroFootprint</div>
    </div>
    <div class="nav-links">
        <a href="home.php">الرئيسية</a>
        <a href="about.php">من نحن</a>
        <a href="login.php">تسجيل الدخول</a>
    </div>
</div>

<div class="form-container">
    <h2>إنشاء حساب</h2>

    <?php if ($error):   ?><div class="error-msg"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <?php if ($success): ?><div class="success-msg"><?= htmlspecialchars($success) ?></div><?php endif; ?>

    <form method="POST" action="">
        <input type="text"     name="name"     placeholder="الاسم الكامل"             required>
        <input type="email"    name="email"    placeholder="البريد الإلكتروني"        required autocomplete="email">
        <input type="password" name="password" placeholder="كلمة المرور (8+ أحرف)"   required minlength="8">
        <select name="role" required>
            <option value="">اختر نوع الحساب</option>
            <option value="user">مستخدم</option>
            <option value="admin">مسؤول</option>
        </select>
        <button type="submit">تسجيل ←</button>
    </form>

    <div class="login-link">لديك حساب؟ <a href="login.php">سجّل الدخول</a></div>
</div>
</body>
</html>
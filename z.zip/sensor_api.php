<?php
/**
 * sensor_api.php — IoT sensor ingestion → Firebase Realtime Database
 * Called by ESP32/Arduino via GET or POST
 *
 * Params: floor_id, temp, humidity, co2
 * Optional: secret (shared key auth)
 */
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

// ── Optional shared-secret auth ───────────────────────────────────────────────
define('SENSOR_SECRET', ''); // Set e.g. 'abc123xyz' to enable

if (SENSOR_SECRET !== '') {
    $provided = $_REQUEST['secret'] ?? '';
    if (!hash_equals(SENSOR_SECRET, $provided)) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Unauthorized']);
        exit;
    }
}

require_once __DIR__ . '/database.php'; // $database

// ── Accept GET or POST ────────────────────────────────────────────────────────
$input    = $_SERVER['REQUEST_METHOD'] === 'POST' ? $_POST : $_GET;
$floorId  = trim($input['floor_id'] ?? '');
$temp     = isset($input['temp'])     ? (float) $input['temp']     : null;
$humidity = isset($input['humidity']) ? (float) $input['humidity'] : null;
$co2      = isset($input['co2'])      ? (float) $input['co2']      : null;

// ── Validate ──────────────────────────────────────────────────────────────────
$errors = [];
if ($floorId === '')    $errors[] = 'floor_id is required';
if ($temp === null)     $errors[] = 'temp is required';
if ($humidity === null) $errors[] = 'humidity is required';
if ($co2 === null)      $errors[] = 'co2 is required';

if ($errors) {
    http_response_code(400);
    echo json_encode(['success' => false, 'errors' => $errors]);
    exit;
}

// ── Write to RTDB ─────────────────────────────────────────────────────────────
try {
    $today  = date('Y-m-d');
    // Sanitize key — RTDB forbids . # $ / [ ]
    $docKey = str_replace(['.', '#', '$', '/', '[', ']'], '_', $floorId) . '_' . $today;

    // update() = merge — preserves electricity/water set by manual_entry or api.php
    $database->getReference('daily_records/' . $docKey)->update([
        'floor_id'        => $floorId,
        'record_date'     => $today,
        'avg_temperature' => $temp,
        'avg_humidity'    => $humidity,
        'avg_co2'         => $co2,
        'last_updated'    => date('c'),
    ]);

    http_response_code(200);
    echo json_encode([
        'success'  => true,
        'message'  => 'Sensor data saved',
        'floor_id' => $floorId,
        'date'     => $today,
        'temp'     => $temp,
        'humidity' => $humidity,
        'co2'      => $co2,
    ]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error'   => 'Failed to write sensor data',
        'detail'  => $e->getMessage(),
    ]);
}
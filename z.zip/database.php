<?php
/**
 * database.php — Firebase Realtime Database bootstrap
 *
 * SDK: kreait/firebase-php
 * Usage: require_once 'database.php';
 * Provides: $database (RTDB), $auth (Firebase Auth)
 */

declare(strict_types=1);

require_once __DIR__ . '/vendor/autoload.php';

use Kreait\Firebase\Factory;
use Kreait\Firebase\Exception\FirebaseException;

// ── Config ────────────────────────────────────────────────────────────────────
define('FIREBASE_CREDENTIALS',   __DIR__ . '/service-account.json');
define('FIREBASE_DATABASE_URL',  'https://fingerprint-3e7ba-default-rtdb.firebaseio.com');

// ── Boot ──────────────────────────────────────────────────────────────────────
try {
    if (!file_exists(FIREBASE_CREDENTIALS)) {
        throw new RuntimeException('Service-account file not found: ' . FIREBASE_CREDENTIALS);
    }

    $factory = (new Factory)
        ->withServiceAccount(FIREBASE_CREDENTIALS)
        ->withDatabaseUri(FIREBASE_DATABASE_URL);

    $auth     = $factory->createAuth();      // Firebase Authentication (Admin SDK)
    $database = $factory->createDatabase();  // Realtime Database

} catch (FirebaseException | RuntimeException $e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => false,
        'error'   => 'Firebase connection failed',
        'detail'  => $e->getMessage(),
    ]);
    exit;
}
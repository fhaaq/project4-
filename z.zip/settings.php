<?php
session_start();
require_once 'database.php';

// ── Session Guard ──────────────────────────────────────────────────────────────
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

$role    = $_SESSION['role'] ?? 'viewer';
$isAdmin = ($role === 'admin');
$ro      = $isAdmin ? '' : 'readonly';

// المسار الصحيح حسب الهيكلة الخاصة بك (settings/limits)[cite: 5]
$settingsRef = $database->getReference('settings/limits'); 

$success = '';
$error   = '';

// ── دالة لضمان أن الأرقام المعروضة والمدخلة هي أرقام إنجليزية فقط ──────────────
function cleanNumber($val) {
    $arabic  = ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
    $persian = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    $english = ['0','1','2','3','4','5','6','7','8','9'];
    $val = str_replace($arabic, $english, (string)$val);
    return str_replace($persian, $english, $val);
}

// ── Handle Save (POST) ────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $isAdmin) {
    try {
        // تنظيف البيانات القادمة من النموذج قبل حفظها في الفايربيس[cite: 7]
        $settingsRef->update([
            'electricity' => floatval(cleanNumber($_POST['electricity'])),
            'water'       => floatval(cleanNumber($_POST['water'])),
            'co2'         => floatval(cleanNumber($_POST['co2'])),
            'people'      => intval(cleanNumber($_POST['people'])),
            'temperature' => floatval(cleanNumber($_POST['temperature'])),
            'humidity'    => floatval(cleanNumber($_POST['humidity'])),
            'update_time' => $_POST['update_time'] ?? '08:00',
            'alert_email' => $_POST['alert_email'] ?? ''
        ]);
        $success = "تم حفظ الإعدادات بنجاح ✅";
    } catch (Throwable $e) {
        $error = "خطأ في الحفظ: " . $e->getMessage();
    }
}

// جلب القيم الحالية من القاعدة[cite: 5, 7]
$settings = $settingsRef->getValue() ?: [];
?>
<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>الإعدادات — ZeroFootprint</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
<style>
/* التصميم الأصلي المعتمد[cite: 7] */
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Cairo',sans-serif;direction:rtl;background:linear-gradient(135deg,#f5f0e6,#e8f5e9);min-height:100vh;}
.navbar{position:fixed;top:0;width:100%;background:#1b5e20;padding:14px 24px;display:flex;justify-content:space-between;align-items:center;color:white;z-index:1000;box-shadow:0 2px 10px rgba(0,0,0,.2);}
.project-name{font-size:22px;font-weight:700;}
.nav-links{display:flex;gap:20px;align-items:center;}
.nav-links a{color:white;text-decoration:none;font-size:15px;opacity:.9;}
.nav-links a:hover{opacity:1;text-decoration:underline;}
.container{padding-top:90px;max-width:680px;margin:auto;padding-bottom:40px;padding-left:20px;padding-right:20px;}
h2{color:#1b5e20;margin:20px 0;font-size:23px;}
.alert-success{padding:12px 18px;border-radius:8px;margin-bottom:16px;font-weight:600;background:#c8e6c9;color:#1b5e20;border:1px solid #2e7d32;}
.alert-error{padding:12px 18px;border-radius:8px;margin-bottom:16px;font-weight:600;background:#ffcdd2;color:#b71c1c;border:1px solid #e53935;}
.card{background:white;border-radius:14px;box-shadow:0 4px 18px rgba(0,0,0,.1);margin-bottom:22px;overflow:hidden;}
.card-header{background:#2e7d32;color:white;padding:14px 20px;font-size:17px;font-weight:700;}
.card-body{padding:22px;}
.form-group{margin-bottom:16px;}
.form-group label{display:block;font-size:13px;font-weight:600;color:#555;margin-bottom:6px;}
.form-group input{width:100%;padding:10px 14px;border-radius:8px;border:1px solid #ccc;font-family:'Cairo',sans-serif;font-size:15px;}
.form-group input:focus{outline:none;border-color:#2e7d32;}
.form-group input[readonly]{background:#f9f9f9;color:#888;cursor:not-allowed;}
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;}
.btn-save{padding:11px 28px;background:#2e7d32;color:white;border:none;border-radius:8px;cursor:pointer;font-family:'Cairo',sans-serif;font-size:15px;font-weight:700;transition:.2s;width:100%;}
.btn-save:hover{background:#1b5e20;}
.role-badge{background:rgba(255,255,255,.2);border-radius:20px;padding:3px 14px;font-size:13px;}
</style>
</head>
<body>
<div class="navbar">
    <div class="project-name">🌿 ZeroFootprint</div>
    <div class="nav-links">
        <span class="role-badge"><?= $isAdmin ? '👑 مسؤول' : '👤 مستخدم' ?></span>
        <a href="dashboard.php">لوحة التحكم</a>
        <a href="reports.php">التقارير</a>
        <a href="logout.php">تسجيل الخروج</a>
    </div>
</div>

<div class="container">
    <h2>⚙️ إعدادات النظام</h2>

    <?php if ($success): ?><div class="alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>
    <?php if ($error):   ?><div class="alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <form method="POST">
        <div class="card">
            <div class="card-header">📊 الحدود القصوى للاستهلاك (الأرقام بالإنجليزية)</div>
            <div class="card-body">
                <div class="form-grid">
                    <div class="form-group">
                        <label>⚡ حد الكهرباء (kWh)</label>
                        <input type="text" name="electricity" lang="en" dir="ltr"
                               value="<?= htmlspecialchars(cleanNumber($settings['electricity'] ?? '0')) ?>" <?= $ro ?> required>
                    </div>
                    <div class="form-group">
                        <label>💧 حد المياه (لتر)</label>
                        <input type="text" name="water" lang="en" dir="ltr"
                               value="<?= htmlspecialchars(cleanNumber($settings['water'] ?? '0')) ?>" <?= $ro ?> required>
                    </div>
                    <div class="form-group">
                        <label>☁️ حد CO₂ (ppm)</label>
                        <input type="text" name="co2" lang="en" dir="ltr"
                               value="<?= htmlspecialchars(cleanNumber($settings['co2'] ?? '0')) ?>" <?= $ro ?> required>
                    </div>
                    <div class="form-group">
                        <label>👤 حد الأشخاص</label>
                        <input type="text" name="people" lang="en" dir="ltr"
                               value="<?= htmlspecialchars(cleanNumber($settings['people'] ?? '0')) ?>" <?= $ro ?> required>
                    </div>
                    <div class="form-group">
                        <label>🌡️ حد الحرارة (°C)</label>
                        <input type="text" name="temperature" lang="en" dir="ltr"
                               value="<?= htmlspecialchars(cleanNumber($settings['temperature'] ?? '0')) ?>" <?= $ro ?> required>
                    </div>
                    <div class="form-group">
                        <label>💦 حد الرطوبة (%)</label>
                        <input type="text" name="humidity" lang="en" dir="ltr"
                               value="<?= htmlspecialchars(cleanNumber($settings['humidity'] ?? '0')) ?>" <?= $ro ?> required>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">🔧 إعدادات النظام الإضافية</div>
            <div class="card-body">
                <div class="form-grid">
                    <div class="form-group">
                        <label>⏰ وقت التحديث التلقائي</label>
                        <input type="time" name="update_time"
                               value="<?= htmlspecialchars($settings['update_time'] ?? '08:00') ?>" <?= $ro ?>>
                    </div>
                    <div class="form-group">
                        <label>📧 البريد للتنبيهات</label>
                        <input type="email" name="alert_email"
                               value="<?= htmlspecialchars($settings['alert_email'] ?? '') ?>"
                               placeholder="admin@example.com" <?= $ro ?>>
                    </div>
                </div>
            </div>
        </div>

        <?php if ($isAdmin): ?>
        <button type="submit" class="btn-save">💾 حفظ الإعدادات</button>
        <?php endif; ?>
    </form>
</div>
</body>
</html>
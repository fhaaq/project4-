<?php
session_start();

// تحقق من تسجيل الدخول
if(!isset($_SESSION['email']) || $_SESSION['role'] !== 'admin'){
    header("Location: login.php");
    exit();
}

// بيانات تجريبية للمباني والطوابق
$buildings = [
    ['id'=>1, 'name'=>'مبنى A', 'floors'=>3],
    ['id'=>2, 'name'=>'مبنى B', 'floors'=>4],
    ['id'=>3, 'name'=>'مبنى C', 'floors'=>2]
];

$userName = $_SESSION['name'] ?? "المسؤول";

// حفظ البيانات المرسلة
$messages = [];
if(isset($_POST['submit_floor'])){
    $building_id = intval($_POST['building_id']);
    $floor = intval($_POST['floor']);
    $electricity = floatval($_POST['electricity']);
    $people = intval($_POST['people']);
    $temperature = floatval($_POST['temperature']);
    $humidity = floatval($_POST['humidity']);
    $water = floatval($_POST['water']);

    // هنا لاحقًا نضيف الحفظ بالداتابيس
    $messages[] = "تم حفظ البيانات لمبنى #$building_id الطابق $floor بنجاح!";
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>إدخال البيانات اليدوية — ZeroFootprint</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
<style>
body {
    margin:0;
    font-family:'Cairo',sans-serif;
    direction:rtl;
    background:linear-gradient(#f5f0e6,#e8f5e9);
}

/* Navbar */
.navbar{
    position:fixed;
    top:0;
    width:100%;
    background:#1b5e20;
    padding:12px 20px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    color:white;
    z-index:1000;
}
.project-name{font-size:22px;font-weight:bold;}
.navbar .welcome{font-size:16px;}
.nav-links{
    display:flex;
    gap:20px;
}
.nav-links a{color:white;text-decoration:none;font-size:16px;white-space:nowrap;}
.nav-links a:hover{text-decoration:underline;}

/* Container */
.container{
    margin-top:130px;
    padding:20px;
    max-width:900px;
    margin-left:auto;
    margin-right:auto;
}

/* Floor Form Card */
.floor-card{
    background:white;
    padding:20px;
    border-radius:12px;
    box-shadow:0 5px 15px rgba(0,0,0,0.15);
    margin-bottom:20px;
}
.floor-card h3{color:#2e7d32;margin-bottom:10px;}
.floor-card input{
    width:100%;
    padding:8px;
    margin:5px 0;
    border-radius:6px;
    border:1px solid #ccc;
    font-size:16px;
}
.floor-card button{
    padding:10px;
    width:100%;
    background:#2e7d32;
    color:white;
    border:none;
    border-radius:6px;
    cursor:pointer;
    font-size:16px;
    margin-top:5px;
}
.floor-card button:hover{background:#1b5e20;}

/* Messages */
.messages{
    margin-bottom:15px;
    padding:10px;
    background:#c8e6c9;
    border:1px solid #2e7d32;
    border-radius:6px;
    color:#2e7d32;
}
</style>
</head>
<body>

<!-- Navbar -->
<div class="navbar">
    <div class="project-name">ZeroFootprint - مرحباً، <?= htmlspecialchars($userName) ?></div>
    <div class="nav-links">
        <a href="dashboard.php">لوحة التحكم</a>
        <a href="manage_buildings.php"> ادارة المباني </a>
        <a href="reports.php">التقارير</a>
        <a href="logout.php">تسجيل الخروج</a>
    </div>
</div>

<!-- Container -->
<div class="container">
<h2>إدخال البيانات اليدوية</h2>

<?php foreach($messages as $msg): ?>
<div class="messages"><?= $msg ?></div>
<?php endforeach; ?>

<?php foreach($buildings as $b): ?>
    <?php for($f=1; $f<=$b['floors']; $f++): ?>
    <div class="floor-card">
        <h3><?= htmlspecialchars($b['name']) ?> - الطابق <?= $f ?></h3>
        <form method="POST">
            <input type="hidden" name="building_id" value="<?= $b['id'] ?>">
            <input type="hidden" name="floor" value="<?= $f ?>">
            <input type="number" name="electricity" placeholder="الكهرباء (kWh)" step="0.01" required>
            <input type="number" name="people" placeholder="عدد الأشخاص" required>
            <input type="number" name="temperature" placeholder="درجة الحرارة (°C)" step="0.1" required>
            <input type="number" name="humidity" placeholder="الرطوبة (%)" step="0.1" required>
            <input type="number" name="water" placeholder="المياه (لتر)" step="0.01" required>
            <button type="submit" name="submit_floor">حفظ بيانات الطابق</button>
        </form>
    </div>
    <?php endfor; ?>
<?php endforeach; ?>

</div>
</body>
</html>
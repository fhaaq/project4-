<?php
session_start();

// تحقق من تسجيل الدخول
if(!isset($_SESSION['email'])){
    header("Location: login.php");
    exit();
}

// بيانات تجريبية للمباني (مستقبلًا تربط بالداتابيس)
$buildings = [
    ['id'=>1, 'name'=>'مبنى A', 'floors'=>3],
    ['id'=>2, 'name'=>'مبنى B', 'floors'=>4],
    ['id'=>3, 'name'=>'مبنى C', 'floors'=>2]
];

// الدور الحالي
$role = $_SESSION['role'];
$userName = $_SESSION['name'] ?? "المستخدم"; // الاسم الحقيقي من الجلسة

// إضافة مبنى جديد
if($role === 'admin' && isset($_POST['add_building'])){
    $newBuilding = [
        'id' => count($buildings)+1,
        'name' => $_POST['building_name'],
        'floors' => intval($_POST['floors'])
    ];
    $buildings[] = $newBuilding;
}

// حذف مبنى
if($role === 'admin' && isset($_POST['delete_building'])){
    $idToDelete = intval($_POST['delete_id']);
    foreach($buildings as $key => $b){
        if($b['id'] === $idToDelete){
            unset($buildings[$key]);
        }
    }
    $buildings = array_values($buildings); // ترتيب الأرقام
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>إدارة المباني — ZeroFootprint</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
<style>
body {
    margin:0;
    font-family:'Cairo',sans-serif;
    direction:rtl;
    background:linear-gradient(#f5f0e6,#e8f5e9);
}

/* Navbar */
.navbar{
    position:fixed;
    top:0;
    width:100%;
    background:#1b5e20;
    padding:12px 20px;
    display:flex;
    justify-content:space-between; /* توزيع العناصر */
    align-items:center;
    color:white;
    z-index:1000;
}

/* صندوق اليمين: اسم الموقع + الترحيب */
.navbar .right-section {
    display:flex;
    align-items:center;
    gap:15px;
}

/* صندوق اليسار: روابط التنقل */
.navbar .left-section {
    display:flex;
    gap:20px;
}

/* روابط */
.navbar a {
    color:white;
    text-decoration:none;
    font-size:16px;
    white-space:nowrap;
}
.navbar a:hover {text-decoration:underline;}

/* Container */
.container{
    margin-top:130px; /* رفع المحتوى أسفل Navbar */
    padding:20px;
    max-width:800px;
    margin-left:auto;
    margin-right:auto;
}

/* Cards */
.building-card{
    background:white;
    padding:20px;
    border-radius:12px;
    box-shadow:0 5px 15px rgba(0,0,0,0.15);
    margin-bottom:15px;
}
.building-card h3{color:#2e7d32;margin-bottom:10px;}
.building-card p{margin:5px 0;}
.building-card form{display:inline-block;}
.building-card button{padding:5px 10px;margin-top:5px;background:#2e7d32;color:white;border:none;border-radius:6px;cursor:pointer;transition:0.3s;}
.building-card button:hover{background:#1b5e20;}

/* Add Building Form */
.add-building{
    background:white;
    padding:20px;
    border-radius:12px;
    box-shadow:0 5px 15px rgba(0,0,0,0.15);
    margin-bottom:25px;
}
.add-building input{padding:8px;margin:5px 0;width:100%;border-radius:6px;border:1px solid #ccc;font-size:16px;}
.add-building button{padding:10px;width:100%;background:#2e7d32;color:white;border:none;border-radius:6px;cursor:pointer;font-size:16px;}
.add-building button:hover{background:#1b5e20;}
</style>
</head>
<body>

<!-- Navbar -->
<div class="navbar">
    <div class="right-section">
        <div class="project-name">ZeroFootprint</div>
        <div class="welcome">مرحباً، <?= htmlspecialchars($userName) ?></div>
    </div>
    <div class="left-section">
        <?php if($role==='admin'): ?>
        <a href="settings.php">الإعدادات</a>
        <?php endif; ?>
        <a href="dashboard.php">لوحة التحكم</a>
        <a href="manual_entry.php"> ادخال البيانات</a>
        <a href="reports.php">التقارير</a>
        <a href="logout.php">تسجيل الخروج</a>
    </div>
</div>

<!-- Container -->
<div class="container">
<h2>إدارة المباني</h2>

<?php if($role==='admin'): ?>
<!-- Add Building Form -->
<div class="add-building">
    <h3>إضافة مبنى جديد</h3>
    <form method="POST">
        <input type="text" name="building_name" placeholder="اسم المبنى" required>
        <input type="number" name="floors" placeholder="عدد الطوابق" min="1" required>
        <button type="submit" name="add_building">إضافة المبنى</button>
    </form>
</div>
<?php endif; ?>

<!-- List of Buildings -->
<?php foreach($buildings as $b): ?>
<div class="building-card">
    <h3><?= htmlspecialchars($b['name']) ?></h3>
    <p>عدد الطوابق: <?= $b['floors'] ?></p>
    <?php if($role==='admin'): ?>
    <form method="POST" style="display:inline;">
        <input type="hidden" name="delete_id" value="<?= $b['id'] ?>">
        <button type="submit" name="delete_building">حذف المبنى</button>
    </form>
    <?php endif; ?>
</div>
<?php endforeach; ?>

</div>
</body>
</html>
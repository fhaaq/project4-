<?php
session_start();
session_destroy();
?>

<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>تسجيل الخروج</title>

<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">

<!-- تحويل بعد 3 ثواني -->
<meta http-equiv="refresh" content="3;url=home.php">

<style>

body {
    margin: 0;
    font-family: 'Cairo', sans-serif;
    direction: rtl;
    background: linear-gradient(#f5f0e6, #e8f5e9); 
    color: #1b5e20;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

/* الصندوق */
.logout-box {
    background: #ffffffcc; 
    padding: 50px;
    border-radius: 12px;
    text-align: center;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    width: 380px;
}

.logout-box h1 {
    color: #1b5e20; 
    margin-bottom: 15px;
}

.logout-box p {
    font-size: 18px;
    color: #444;
}

</style>

</head>

<body>

<div class="logout-box">
    <h1>تم تسجيل الخروج بنجاح</h1>
    <p>سيتم تحويلك للصفحة الرئيسية خلال 3 ثواني...</p>
</div>

</body>
</html>
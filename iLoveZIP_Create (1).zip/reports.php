<?php
session_start();

// حماية الصفحة
if(!isset($_SESSION['role'])){
    header("Location: login.php");
    exit();
}

// بيانات الطوابق
$floors = ['الطابق 1','الطابق 2','الطابق 3','الطابق 4'];
?>
<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>التقارير — ZeroFootprint</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
<style>
body{margin:0;font-family:'Cairo',sans-serif;direction:rtl;background:linear-gradient(#f5f0e6,#e8f5e9);}
.navbar{position:fixed;top:0;width:100%;background:#1b5e20;padding:12px 20px;display:flex;justify-content:space-between;align-items:center;color:white;z-index:1000;}
.project-name{font-size:22px;font-weight:bold;}
.nav-links{display:flex;gap:20px;}
.nav-links a{color:white;text-decoration:none;font-size:16px;}
.nav-links a:hover{text-decoration:underline;}
.container{margin-top:100px;padding:20px;}
.filter{margin-bottom:25px;display:flex;gap:15px;flex-wrap:wrap;align-items:center;}
.filter label{font-weight:bold;margin-right:5px;}
.filter .checkbox-group{display:flex;gap:15px;align-items:center;}
.filter input[type=date]{padding:8px;border-radius:6px;border:1px solid #ccc;font-size:16px;}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:20px;}
.card{background:white;padding:20px;border-radius:12px;box-shadow:0 5px 15px rgba(0,0,0,0.15);text-align:center;}
.card h3{margin-bottom:10px;color:#2e7d32;}
.chart{margin-top:30px;background:white;padding:25px;border-radius:12px;box-shadow:0 5px 15px rgba(0,0,0,0.15);max-width:400px;margin-left:auto;margin-right:auto;}
</style>
</head>
<body>

<div class="navbar">
    <div class="project-name">ZeroFootprint-مرحبا <?= $_SESSION['name'] ?></div>
    <div class="nav-links">
        <?php if($_SESSION['role'] === 'admin'): ?>
        <a href="dashboard.php">لوحة التحكم</a>
        <a href="settings.php">الإعدادات</a>
        <?php endif; ?>
        <a href="logout.php">تسجيل الخروج</a>
    </div>
</div>

<div class="container">
<h2>التقارير</h2>

<!-- Filter -->
<form class="filter">
<label>اختر الطوابق:</label>
<div class="checkbox-group">
<?php foreach($floors as $floor): ?>
    <label><input type="checkbox" name="floors[]" value="<?= $floor ?>"> <?= $floor ?></label>
<?php endforeach; ?>
</div>

<label>من تاريخ:</label>
<input type="date" name="from_date">

<label>إلى تاريخ:</label>
<input type="date" name="to_date">
</form>

<!-- Summary Cards -->
<div class="cards">
<div class="card"><h3>إجمالي البصمة</h3><h2>420 kg CO₂</h2></div>
<div class="card"><h3>أكثر طابق استهلاكاً</h3><h2>الطابق 3</h2></div>
<div class="card"><h3>عدد الأشخاص</h3><h2>128</h2></div>
<div class="card"><h3>متوسط الحرارة</h3><h2>26°C</h2></div>
<div class="card"><h3>متوسط الرطوبة</h3><h2>55%</h2></div>
</div>

<!-- Charts -->
<div class="chart">
<h3>التقرير الأسبوعي</h3>
<canvas id="weeklyChart" style="max-width:350px;"></canvas>
</div>

<div class="chart">
<h3>مكونات البصمة الكربونية الشهرية</h3>
<canvas id="pieChart" style="max-width:300px;"></canvas>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
new Chart(document.getElementById('weeklyChart'), {
    type:'bar',
    data:{
        labels:['السبت','الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة'],
        datasets:[{
            label:'CO₂ (kg)',
            data:[300,350,400,370,420,390,410],
            backgroundColor:'#2e7d32'
        }]
    },
    options:{responsive:true,plugins:{legend:{display:false}}}
});

new Chart(document.getElementById('pieChart'), {
    type:'pie',
    data:{
        labels:['كهرباء','مياه','أشخاص','أخرى'],
        datasets:[{
            data:[45,25,20,10],
            backgroundColor:['#2e7d32','#66bb6a','#a5d6a7','#c8e6c9']
        }]
    },
    options:{responsive:true,plugins:{legend:{position:'bottom'}}}
});
</script>

</body>
</html>
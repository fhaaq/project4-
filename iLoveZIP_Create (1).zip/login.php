<?php
session_start();

// بيانات تجريبية مؤقتة (يمكن استبدالها لاحقاً بقاعدة بيانات)
$users = [
    ['email' => 'admin@example.com', 'password' => 'admin123', 'role' => 'admin', 'name'=>'أحمد المسؤول'],
    ['email' => 'user@example.com', 'password' => 'user123', 'role' => 'user', 'name'=>'سارة المستخدم']
];

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $found = false;
    foreach ($users as $user) {
        if ($user['email'] === $email && $user['password'] === $password) {
            $found = true;
            $_SESSION['email'] = $email;
            $_SESSION['role'] = $user['role'];
            $_SESSION['name'] = $user['name'];

            // تحويل حسب الدور
            if ($user['role'] === 'admin') {
                header("Location: dashboard.php"); // لوحة التحكم
                exit();
            } else {
                header("Location: reports.php"); // التقارير
                exit();
            }
        }
    }

    if (!$found) {
        $error = "البريد الإلكتروني أو كلمة المرور غير صحيحة!";
    }
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>تسجيل الدخول</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">

<style>
body {
    margin: 0;
    font-family: 'Cairo', sans-serif;
    direction: rtl;
    background: linear-gradient(#f5f0e6, #e8f5e9);
    color: #1b5e20;
    display: flex;
    flex-direction: column;
    align-items: center;
}

/* Navbar */
.navbar {
    position: fixed;
    top: 0;
    width: 100%;
    background: #1b5e20;
    padding: 12px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: white;
    z-index: 1000;
}
.logo-area { display: flex; align-items: center; }
.logo-area img { width: 40px; margin-left: 10px; }
.project-name { font-size: 20px; font-weight: bold; }
.nav-links { display: flex; gap: 20px; }
.nav-links a { color: white; text-decoration: none; font-size: 16px; padding: 5px 10px; }
.nav-links a:hover { text-decoration: underline; }

/* Form */
.form-container {
    margin-top: 140px;
    background: rgba(255, 255, 255, 0.85);
    padding: 40px;
    border-radius: 12px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    width: 350px;
    margin-right: auto;
    margin-left: auto;
}
.form-container h2 {
    text-align: center;
    margin-bottom: 25px;
    color: #2e7d32;
}
.form-container input {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border-radius: 6px;
    border: 1px solid #ccc;
    font-size: 16px;
}
.form-container button {
    width: 100%;
    padding: 12px;
    background-color: #2e7d32;
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 18px;
    cursor: pointer;
}
.form-container button:hover { background-color: #1b5e20; }
.error-msg {
    color: red;
    text-align: center;
    margin-bottom: 15px;
}
</style>
</head>
<body>

<div class="navbar">
    <div class="logo-area">
        <img src="logo.png" alt="logo">
        <div class="project-name">ZeroFootprint</div>
    </div>
    <div class="nav-links">
        <a href="home.php">الرئيسية</a>
        <a href="about.php">من نحن</a>
        <a href="register.php">إنشاء حساب</a>
    </div>
</div>

<div class="form-container">
    <h2>تسجيل الدخول</h2>
    <?php if($error) echo "<div class='error-msg'>$error</div>"; ?>
    <form method="POST">
        <input type="email" name="email" placeholder="البريد الإلكتروني" required>
        <input type="password" name="password" placeholder="كلمة المرور" required>
        <button type="submit">دخول</button>
    </form>
</div>

</body>
</html>
<?php
session_start();

// حماية الصفحة: فقط المسؤول
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: login.php");
    exit();
}

// بيانات الطوابق مبدئية
$floors = [
    ['name'=>'الطابق 1','electricity'=>120,'water'=>50,'people'=>30,'temperature'=>25,'humidity'=>50],
    ['name'=>'الطابق 2','electricity'=>200,'water'=>40,'people'=>25,'temperature'=>27,'humidity'=>55],
    ['name'=>'الطابق 3','electricity'=>300,'water'=>60,'people'=>35,'temperature'=>26,'humidity'=>60],
    ['name'=>'الطابق 4','electricity'=>150,'water'=>30,'people'=>20,'temperature'=>24,'humidity'=>45]
];
?>
<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>لوحة التحكم — ZeroFootprint</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
<style>
body{margin:0;font-family:'Cairo',sans-serif;direction:rtl;background:linear-gradient(#f5f0e6,#e8f5e9);}
.navbar{position:fixed;top:0;width:100%;background:#1b5e20;padding:12px 20px;display:flex;justify-content:space-between;align-items:center;color:white;z-index:1000;}
.project-name{font-size:22px;font-weight:bold;}
.nav-links{display:flex;gap:20px;}
.nav-links a{color:white;text-decoration:none;font-size:16px;}
.nav-links a:hover{text-decoration:underline;}
.container{margin-top:100px;padding:20px;}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:20px;}
.card{background:white;padding:20px;border-radius:12px;box-shadow:0 5px 15px rgba(0,0,0,0.15);text-align:center;}
.card h3{margin-bottom:10px;color:#2e7d32;}
.card input{width:70px;padding:5px;margin:5px;border-radius:6px;border:1px solid #ccc;}
.card button{padding:8px 12px;margin-top:10px;background:#2e7d32;color:white;border:none;border-radius:6px;cursor:pointer;transition:0.3s;}
.card button:hover{background:#1b5e20;}
.chart{margin-top:30px;background:white;padding:25px;border-radius:12px;box-shadow:0 5px 15px rgba(0,0,0,0.15);max-width:400px;margin:auto;}
</style>
</head>
<body>

<div class="navbar">
    <div class="project-name">ZeroFootprint - مرحباً <?= $_SESSION['name'] ?></div>
    <div class="nav-links">
        <a href="reports.php">التقارير</a>
        <a href="manage_buildings.php"> ادارة المباني </a>
        <a href="manual_entry.php"> ادخال البيانات</a>
        <a href="settings.php">الإعدادات</a>
        <a href="logout.php">تسجيل الخروج</a>
    </div>
</div>

<div class="container">
<h2>لوحة التحكم الديناميكية</h2>
<div class="cards">
<?php foreach($floors as $floor): ?>
<div class="card">
<h3><?= $floor['name'] ?></h3>
<p>الكهرباء: <input type="number" value="<?= $floor['electricity'] ?>"> kWh</p>
<p>المياه: <input type="number" value="<?= $floor['water'] ?>"> L</p>
<p>الأشخاص: <input type="number" value="<?= $floor['people'] ?>"></p>
<p>درجة الحرارة: <input type="number" value="<?= $floor['temperature'] ?>">°C</p>
<p>الرطوبة: <input type="number" value="<?= $floor['humidity'] ?>">%</p>
<button>تحديث</button>
</div>
<?php endforeach; ?>
</div>

<div class="chart">
<h3>التقرير الأسبوعي للطوابق</h3>
<canvas id="weeklyChart"></canvas>
</div>

<div class="chart">
<h3>مكونات البصمة الكربونية</h3>
<canvas id="pieChart"></canvas>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>

// Weekly Chart
const labels = ['السبت','الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة'];
const data = {
    labels: labels,
    datasets: [
        { label: 'الطابق 1', data: [120,130,125,140,150,135,145], backgroundColor:'#2e7d32' },
        { label: 'الطابق 2', data: [200,210,190,205,220,215,225], backgroundColor:'#66bb6a' },
        { label: 'الطابق 3', data: [300,310,305,320,330,315,325], backgroundColor:'#a5d6a7' },
        { label: 'الطابق 4', data: [150,160,155,170,180,165,175], backgroundColor:'#c8e6c9' }
    ]
};
new Chart(document.getElementById('weeklyChart'), { type:'bar', data:data, options:{responsive:true} });

// Pie Chart
const pieData = {
    labels: ['كهرباء','مياه','أشخاص','أخرى'],
    datasets:[{ data:[45,25,20,10], backgroundColor:['#2e7d32','#66bb6a','#a5d6a7','#c8e6c9'] }]
};
new Chart(document.getElementById('pieChart'), { type:'pie', data:pieData, options:{responsive:true, plugins:{legend:{position:'bottom'}}} });
</script>

</body>
</html>
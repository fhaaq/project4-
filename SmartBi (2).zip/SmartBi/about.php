<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>من نحن - ZeroFootprint</title>

<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">

<style>
/* ===== Body ===== */
body {
    margin: 0;
    font-family: 'Cairo', sans-serif;
    direction: rtl;
    background: linear-gradient(#f5f0e6, #e8f5e9); 
    color: #1b5e20;
}

/* ===== Navbar ===== */
.navbar {
    position: fixed;
    top: 0;
    width: 100%;
    background: #1b5e20;
    padding: 12px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: white;
    z-index: 1000;
}

.logo-area {
    display: flex;
    align-items: center;
}

.logo-area img {
    width: 40px;
    margin-left: 10px;
}

.project-name {
    font-size: 20px;
    font-weight: bold;
}

.nav-links {
    display: flex;
    gap: 25px;
}

.nav-links a {
    color: white;
    text-decoration: none;
    font-size: 16px;
    white-space: nowrap;
    display: inline-block;
    padding: 5px 10px;
}

.nav-links a:hover {
    text-decoration: underline;
}
/* ===== Content Container ===== */
.container{
    margin-top: 140px; 
    max-width: 800px;
    margin-right: auto;
    margin-left: auto;
    background: rgba(255,255,255,0.85); 
    padding: 40px;
    border-radius: 12px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
}

h1{
    text-align: center;
    color: #2e7d32;
    margin-bottom: 25px;
}

p{
    line-height: 1.8;
    font-size: 18px;
    text-align: center;
}

</style>
</head>

<body>

<!-- ===== Navbar ===== -->
<div class="navbar">

    <div class="logo-area">
        <img src="logo.png" alt="logo">
        <div class="project-name">ZeroFootprint</div>
    </div>

    <div class="nav-links">
         <a href="contact.php">تواصل معنا </a>
        <a href="home.php">الرئيسية</a>
        <a href="login.php">تسجيل الدخول</a>
        <a href="register.php">إنشاء حساب</a>
    </div>

</div>

<!-- ===== About Content ===== -->
<div class="container">

<h1>من نحن</h1>

<p>
نحن فريق من متدربي الكلية التقنية الرقمية نعمل على تطوير منصة رقمية ذكية
لقياس وتحليل البصمة الكربونية في المباني.
</p>

<p>
يهدف مشروعنا إلى مساعدة الأفراد والمنشآت على فهم تأثير استهلاك الطاقة والنشاط اليومي على البيئة، 
واتخاذ قرارات واعية تساعد على تحسين الكفاءة وتقليل الانبعاثات.
</p>

<p>
نسعى من خلال "ZeroFootprint" نحو مدينة مستدامة ومجتمع واعٍ بيئيًا، 
حيث يمكن للجميع المشاركة في تقليل البصمة الكربونية وتحقيق تأثير إيجابي على البيئة.
</p>

</div>

</body>
</html>
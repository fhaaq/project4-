<?php
session_start();
include 'database.php';

if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: login.php");
    exit();
}

$today = date('Y-m-d');

/* ========== حفظ ========== */
if(isset($_POST['update_floor'])){

    $floor_id = intval($_POST['floor_id']);
    $electricity = floatval($_POST['electricity']);
    $water = floatval($_POST['water']);

    $check = $conn->query("
        SELECT id FROM Daily_Records 
        WHERE floor_id = $floor_id AND record_date = '$today'
    ");

    if($check->num_rows > 0){
        $conn->query("
            UPDATE Daily_Records SET
            total_electricity = $electricity,
            total_water = $water
            WHERE floor_id = $floor_id AND record_date = '$today'
        ");
    } else {
        $conn->query("
            INSERT INTO Daily_Records 
            (floor_id, total_electricity, total_water, record_date)
            VALUES ($floor_id, $electricity, $water, '$today')
        ");
    }
}

/* ========== جلب البيانات ========== */
$floors = [];

$res = $conn->query("
SELECT 
    Floors.id,
    Floors.floor_number,
    Buildings.name as building_name,
    Daily_Records.total_electricity,
    Daily_Records.total_water,
    Daily_Records.avg_temperature,
    Daily_Records.avg_humidity,
    Daily_Records.avg_co2
FROM Floors
JOIN Buildings ON Floors.building_id = Buildings.id
LEFT JOIN Daily_Records 
ON Floors.id = Daily_Records.floor_id 
AND Daily_Records.record_date = '$today'
");

while($row = $res->fetch_assoc()){
    $floors[] = $row;
}

/* ========== بيانات الرسوم ========== */
$labels = [];
$data = [];

foreach($floors as $f){
    $labels[] = $f['building_name']." ط".$f['floor_number'];
    $co2 = (($f['total_electricity'] ?? 0)*0.5)+(($f['total_water'] ?? 0)*0.0003);
    $data[] = round($co2,2);
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<title>لوحة التحكم — ZeroFootprint</title>

<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">

<!-- أيقونات -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
body{margin:0;font-family:'Cairo',sans-serif;direction:rtl;background:linear-gradient(#f5f0e6,#e8f5e9);}
.navbar{position:fixed;top:0;width:100%;background:#1b5e20;padding:12px 20px;display:flex;justify-content:space-between;align-items:center;color:white;z-index:1000;}
.project-name{font-size:22px;font-weight:bold;}
.nav-links{display:flex;gap:20px;}
.nav-links a{color:white;text-decoration:none;font-size:16px;}
.nav-links a:hover{text-decoration:underline;}
.container{margin-top:100px;padding:20px;}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:20px;}
.card{background:white;padding:20px;border-radius:12px;box-shadow:0 5px 15px rgba(0,0,0,0.15);text-align:center;}
.card h3{margin-bottom:10px;color:#2e7d32;}
.card input{width:70px;padding:5px;margin:5px;border-radius:6px;border:1px solid #ccc;}
.card button{padding:8px 12px;margin-top:10px;background:#2e7d32;color:white;border:none;border-radius:6px;cursor:pointer;}
.card button:hover{background:#1b5e20;}
.chart{margin-top:30px;background:white;padding:25px;border-radius:12px;box-shadow:0 5px 15px rgba(0,0,0,0.15);max-width:400px;margin:auto;}

/* تحسين بسيط بدون تغيير الشكل */
.card p{
    display:flex;
    align-items:center;
    justify-content:space-between;
}
.card i{
    color:#2e7d32;
}
</style>
</head>

<body>

<div class="navbar">
    <div class="project-name">ZeroFootprint - مرحباً <?= $_SESSION['name'] ?></div>
    <div class="nav-links">
        <a href="reports.php">التقارير</a>
        <a href="manage_buildings.php">ادارة المباني</a>
        <a href="manual_entry.php">ادخال البيانات</a>
        <a href="settings.php">الإعدادات</a>
        <a href="logout.php">تسجيل الخروج</a>
    </div>
</div>

<div class="container">
<h2>لوحة التحكم الديناميكية</h2>

<div class="cards">

<?php foreach($floors as $floor): ?>

<?php
$co2 = (($floor['total_electricity'] ?? 0)*0.5)+(($floor['total_water'] ?? 0)*0.0003);
?>

<div class="card">

<form method="POST">

<h3><?= htmlspecialchars($floor['building_name']) ?> - طابق <?= $floor['floor_number'] ?></h3>

<input type="hidden" name="floor_id" value="<?= $floor['id'] ?>">

<p><i class="fas fa-bolt"></i> الكهرباء:
<input type="number" name="electricity" value="<?= $floor['total_electricity'] ?? 0 ?>">
</p>

<p><i class="fas fa-tint"></i> المياه:
<input type="number" name="water" value="<?= $floor['total_water'] ?? 0 ?>">
</p>

<p><i class="fas fa-thermometer-half"></i> الحرارة:
<input type="number" value="<?= $floor['avg_temperature'] ?? '—' ?>" readonly>
</p>

<p><i class="fas fa-water"></i> الرطوبة:
<input type="number" value="<?= $floor['avg_humidity'] ?? '—' ?>" readonly>
</p>

<p><i class="fas fa-cloud"></i> CO₂:
<input type="number" value="<?= $floor['avg_co2'] ?? '—' ?>" readonly>
</p>

<p>
<i class="fas fa-leaf"></i>
<strong>البصمة: <?= round($co2,2) ?> kg CO₂</strong>
</p>

<button type="submit" name="update_floor">تحديث</button>

</form>

</div>

<?php endforeach; ?>

</div>

<!-- رسم الطوابق -->
<div class="chart">
<h3>مقارنة الطوابق (CO2)</h3>
<canvas id="floorChart"></canvas>
</div>

<!-- رسم دائري -->
<div class="chart">
<h3>نسبة الاستهلاك</h3>
<canvas id="pieChart"></canvas>
</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
new Chart(document.getElementById('floorChart'), {
    type:'bar',
    data:{
        labels: <?= json_encode($labels) ?>,
        datasets:[{
            data: <?= json_encode($data) ?>,
            backgroundColor:'#2e7d32'
        }]
    },
    options:{plugins:{legend:{display:false}}}
});

new Chart(document.getElementById('pieChart'), {
    type:'pie',
    data:{
        labels: <?= json_encode($labels) ?>,
        datasets:[{
            data: <?= json_encode($data) ?>,
            backgroundColor:['#2e7d32','#66bb6a','#a5d6a7','#c8e6c9']
        }]
    }
});
</script>

</body>
</html>
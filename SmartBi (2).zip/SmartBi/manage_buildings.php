<?php
session_start();
include 'database.php';

// تحقق تسجيل الدخول
if(!isset($_SESSION['email'])){
    header("Location: login.php");
    exit();
}

$role = $_SESSION['role'];
$userName = $_SESSION['name'] ?? "المستخدم";

/* ================== إضافة مبنى ================== */
if($role === 'admin' && isset($_POST['add_building'])){
    $name = $_POST['building_name'];
    $conn->query("INSERT INTO Buildings (name) VALUES ('$name')");
}

/* ================== حذف مبنى ================== */
if($role === 'admin' && isset($_POST['delete_building'])){
    $idToDelete = intval($_POST['delete_id']);
    $conn->query("DELETE FROM Buildings WHERE id = $idToDelete");
}

/* ================== إضافة طابق ================== */
if($role === 'admin' && isset($_POST['add_floor'])){
    $building_id = $_POST['building_id'];
    $floor_number = $_POST['floor_number'];
    $floor_area = $_POST['floor_area'];

    $conn->query("
        INSERT INTO Floors (building_id, floor_number, floor_area)
        VALUES ($building_id, $floor_number, $floor_area)
    ");
}

/* ================== حذف طابق ================== */
if($role === 'admin' && isset($_POST['delete_floor'])){
    $floor_id = intval($_POST['floor_id']);
    $conn->query("DELETE FROM Floors WHERE id = $floor_id");
}

/* ================== جلب المباني ================== */
$buildings = [];
$result = $conn->query("SELECT * FROM Buildings");

while($row = $result->fetch_assoc()){
    $buildings[] = $row;
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>إدارة المباني — ZeroFootprint</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">

<style>
body {
    margin:0;
    font-family:'Cairo',sans-serif;
    direction:rtl;
    background:linear-gradient(#f5f0e6,#e8f5e9);
}

/* Navbar */
.navbar{
    position:fixed;
    top:0;
    width:100%;
    background:#1b5e20;
    padding:12px 20px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    color:white;
    z-index:1000;
}

.navbar .right-section {
    display:flex;
    align-items:center;
    gap:15px;
}

.navbar .left-section {
    display:flex;
    gap:20px;
}

.navbar a {
    color:white;
    text-decoration:none;
}

.container{
    margin-top:130px;
    padding:20px;
    max-width:800px;
    margin:auto;
}

/* Cards */
.building-card{
    background:white;
    padding:20px;
    border-radius:12px;
    box-shadow:0 5px 15px rgba(0,0,0,0.15);
    margin-bottom:20px;
}

/* Form */
input{
    padding:8px;
    margin:5px 0;
    width:100%;
    border-radius:6px;
    border:1px solid #ccc;
}

button{
    padding:8px 12px;
    background:#2e7d32;
    color:white;
    border:none;
    border-radius:6px;
    cursor:pointer;
}
button:hover{
    background:#1b5e20;
}

.floor-box{
    margin-top:10px;
    padding:10px;
    background:#f9f9f9;
    border-radius:8px;
}
</style>
</head>

<body>

<!-- Navbar -->
<div class="navbar">
    <div class="right-section">
        <div>ZeroFootprint</div>
        <div>مرحباً، <?= htmlspecialchars($userName) ?></div>
    </div>
    <div class="left-section">
        <a href="dashboard.php">لوحة التحكم</a>
        <a href="manual_entry.php">إدخال البيانات</a>
        <a href="reports.php">التقارير</a>
        <a href="logout.php">خروج</a>
    </div>
</div>

<div class="container">

<h2>إدارة المباني</h2>

<?php if($role==='admin'): ?>
<!-- إضافة مبنى -->
<div class="building-card">
    <h3>إضافة مبنى</h3>
    <form method="POST">
        <input type="text" name="building_name" placeholder="اسم المبنى" required>
        <button name="add_building">إضافة</button>
    </form>
</div>
<?php endif; ?>

<!-- عرض المباني -->
<?php foreach($buildings as $b): ?>
<div class="building-card">

    <h3><?= htmlspecialchars($b['name']) ?></h3>

    <?php
    $floorCount = $conn->query("
        SELECT COUNT(*) as total 
        FROM Floors 
        WHERE building_id = {$b['id']}
    ")->fetch_assoc()['total'];
    ?>

    <p>عدد الطوابق: <?= $floorCount ?></p>

    <!-- الطوابق -->
    <?php
    $floors = $conn->query("SELECT * FROM Floors WHERE building_id = {$b['id']}");
    ?>

    <div class="floor-box">
        <strong>الطوابق:</strong>

        <?php while($f = $floors->fetch_assoc()): ?>
        <div style="margin-top:8px; background:white; padding:8px; border-radius:6px;">
            طابق <?= $f['floor_number'] ?> — <?= $f['floor_area'] ?> م²

            <?php if($role==='admin'): ?>
            <form method="POST" style="display:inline;">
                <input type="hidden" name="floor_id" value="<?= $f['id'] ?>">
                <button name="delete_floor" onclick="return confirm('حذف الطابق؟')">حذف</button>
            </form>
            <?php endif; ?>
        </div>
        <?php endwhile; ?>

        <?php if($role==='admin'): ?>
        <!-- إضافة طابق -->
        <form method="POST" style="margin-top:10px;">
            <input type="hidden" name="building_id" value="<?= $b['id'] ?>">
            <input type="number" name="floor_number" placeholder="رقم الطابق" required>
            <input type="number" name="floor_area" placeholder="المساحة" required>
            <button name="add_floor">إضافة طابق</button>
        </form>
        <?php endif; ?>
    </div>

    <?php if($role==='admin'): ?>
    <!-- حذف مبنى -->
    <form method="POST" style="margin-top:10px;">
        <input type="hidden" name="delete_id" value="<?= $b['id'] ?>">
        <button name="delete_building" onclick="return confirm('حذف المبنى؟')">حذف المبنى</button>
    </form>
    <?php endif; ?>

</div>
<?php endforeach; ?>

</div>
</body>
</html>
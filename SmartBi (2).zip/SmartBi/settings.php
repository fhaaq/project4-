<?php
session_start();
include 'database.php'; // ملف الاتصال بقاعدة البيانات

// التحقق من تسجيل الدخول
if(!isset($_SESSION['email'])){
    header("Location: login.php");
    exit();
}

// جلب بيانات المستخدم من قاعدة البيانات
$email = $_SESSION['email'];
$stmt = $conn->prepare("SELECT * FROM users WHERE email=? LIMIT 1");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$current_user = $result->fetch_assoc();

if(!$current_user){
    die("المستخدم غير موجود!");
}

// جلب الإعدادات الحالية
$settings_result = $conn->query("SELECT * FROM settings LIMIT 1");
$settings = $settings_result->fetch_assoc();

// التعامل مع حفظ الإعدادات (فقط للمسؤول)
$success = '';
if($_SERVER["REQUEST_METHOD"] == "POST" && $current_user['role'] === 'admin'){
    $electricity_limit = $_POST['electricity_limit'];
    $people_limit = $_POST['people_limit'];
    $temp_limit = $_POST['temp_limit'];
    $humidity_limit = $_POST['humidity_limit'];
    $update_time = $_POST['update_time'];

    $stmt = $conn->prepare("UPDATE settings SET electricity_limit=?, people_limit=?, temp_limit=?, humidity_limit=?, update_time=? WHERE id=1");
    $stmt->bind_param("iiiis", $electricity_limit, $people_limit, $temp_limit, $humidity_limit, $update_time);
    $stmt->execute();

    // إعادة جلب القيم بعد الحفظ
    $settings_result = $conn->query("SELECT * FROM settings LIMIT 1");
    $settings = $settings_result->fetch_assoc();

    $success = "تم حفظ الإعدادات بنجاح!";
}
?>
<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>الإعدادات — ZeroFootprint</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
<style>
body{ margin:0; font-family:'Cairo',sans-serif; direction:rtl; background:linear-gradient(#f5f0e6,#e8f5e9);}
.navbar{ position:fixed; top:0; width:100%; background:#1b5e20; padding:12px 20px; display:flex; justify-content:space-between; align-items:center; color:white; z-index:1000;}
.project-name { font-size:22px;font-weight:bold; }
.navbar-right { display:flex; gap:20px; align-items:center; }
.navbar-right a { color:white;text-decoration:none;font-size:16px; }
.navbar-right a:hover { text-decoration:underline; }
.navbar-right span { font-weight:bold; }
.container{ margin-top:120px; padding:20px; max-width:600px; margin-left:auto; margin-right:auto; }
.card{ background:white; padding:20px; border-radius:12px; box-shadow:0 5px 15px rgba(0,0,0,0.15); margin-bottom:20px; }
.card h3{color:#2e7d32;margin-bottom:15px;text-align:center;}
.card label{display:block;margin:8px 0;font-weight:bold;}
.card input, .card select{ width:100%; padding:8px; margin-bottom:12px; border-radius:6px; border:1px solid #ccc; font-size:16px; }
.card button{ padding:10px 15px; background:#2e7d32; color:white; border:none; border-radius:6px; cursor:pointer; font-size:16px; transition:0.3s; }
.card button:hover{background:#1b5e20;}
.success-msg { color:green; text-align:center; margin-bottom:15px; font-weight:bold; }
</style>
</head>
<body>
<div class="navbar">
    <div class="project-name">ZeroFootprint</div>
    <div class="navbar-right">
        <span>مرحبا <?= htmlspecialchars($current_user['name']) ?></span>
        <a href="dashboard.php">لوحة التحكم</a>
        <a href="reports.php">التقارير</a>
        <a href="logout.php">تسجيل الخروج</a>
    </div>
</div>

<div class="container">
<h2>إعدادات النظام</h2>
<?php if($success) echo "<div class='success-msg'>$success</div>"; ?>

<div class="card">
<h3>الحدود والقيم القصوى</h3>
<form action="#" method="post">
    <label>الحد الأعلى للكهرباء (kWh)</label>
    <input type="number" name="electricity_limit" value="<?= htmlspecialchars($settings['electricity_limit']) ?>" <?= $current_user['role'] !== 'admin' ? 'readonly' : '' ?> required>

    <label>الحد الأعلى للأشخاص</label>
    <input type="number" name="people_limit" value="<?= htmlspecialchars($settings['people_limit']) ?>" <?= $current_user['role'] !== 'admin' ? 'readonly' : '' ?> required>

    <label>الحد الأعلى للحرارة (°C)</label>
    <input type="number" name="temp_limit" value="<?= htmlspecialchars($settings['temp_limit']) ?>" <?= $current_user['role'] !== 'admin' ? 'readonly' : '' ?> required>

    <label>الحد الأعلى للرطوبة (%)</label>
    <input type="number" name="humidity_limit" value="<?= htmlspecialchars($settings['humidity_limit']) ?>" <?= $current_user['role'] !== 'admin' ? 'readonly' : '' ?> required>

    <label>وقت التحديث التلقائي</label>
    <input type="time" name="update_time" value="<?= htmlspecialchars($settings['update_time']) ?>" <?= $current_user['role'] !== 'admin' ? 'readonly' : '' ?> required>

    <?php if($current_user['role'] === 'admin'): ?>
        <button type="submit">حفظ الإعدادات</button>
    <?php endif; ?>
</form>
</div>
</div>
</body>
</html>
<?php
include 'database.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    // 🔥 حفظ البيانات في الداتابيس
    $sql = "INSERT INTO users (name, email, password, role)
            VALUES ('$name', '$email', '$password', '$role')";

    if ($conn->query($sql) === TRUE) {
        header("Location: login.php");
        exit();
    } else {
        echo "خطأ: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>إنشاء حساب</title>

<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">

<style>
body {
    margin: 0;
    font-family: 'Cairo', sans-serif;
    direction: rtl;
    background: linear-gradient(#f5f0e6, #e8f5e9);
    color: #1b5e20;
}

/* ===== Navbar ===== */
.navbar {
    position: fixed;
    top: 0;
    width: 100%;
    background: #1b5e20;
    padding: 12px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: white;
    z-index: 1000;
}

.logo-area {
    display: flex;
    align-items: center;
}

.logo-area img {
    width: 40px;
    margin-left: 10px;
}

.project-name {
    font-size: 20px;
    font-weight: bold;
}

.nav-links {
    display: flex;
    gap: 20px;
}

.nav-links a {
    color: white;
    text-decoration: none;
    font-size: 16px;
    padding: 5px 10px;
}

.nav-links a:hover {
    text-decoration: underline;
}

/* ===== Form ===== */
.form-container {
    margin-top: 140px;
    background: rgba(255, 255, 255, 0.85);
    padding: 40px;
    border-radius: 12px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    width: 350px;
    margin-right: auto;
    margin-left: auto;
}

.form-container h2 {
    text-align: center;
    margin-bottom: 25px;
    color: #2e7d32;
}

.form-container input,
.form-container select {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border-radius: 6px;
    border: 1px solid #ccc;
    font-size: 16px;
}

.form-container button {
    width: 100%;
    padding: 12px;
    background-color: #2e7d32;
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 18px;
    cursor: pointer;
    transition: background 0.3s;
}

.form-container button:hover {
    background-color: #1b5e20;
}
</style>
</head>

<body>

<!-- ===== Navbar ===== -->
<div class="navbar">
    <div class="logo-area">
        <img src="logo.png" alt="logo">
        <div class="project-name">ZeroFootprint</div>
    </div>

    <div class="nav-links">
        <a href="home.php">الرئيسية</a>
        <a href="about.php">من نحن</a>
        <a href="login.php">تسجيل الدخول</a>
    </div>
</div>

<!-- ===== Form ===== -->
<div class="form-container">
    <h2>إنشاء حساب</h2>

    <form method="POST">

        <input type="text" name="name" placeholder="الاسم الكامل" required>

        <input type="email" name="email" placeholder="البريد الإلكتروني" required>

        <input type="password" name="password" placeholder="كلمة المرور" required>

        <!-- 👇 اختيار نوع الحساب -->
        <select name="role" required>
            <option value="">اختر نوع الحساب</option>
            <option value="user">مستخدم</option>
            <option value="admin">مسؤول</option>
        </select>

        <button type="submit">تسجيل</button>

    </form>
</div>

</body>
</html>
<html lang="ar" dir="rtl">
<head>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ZeroFootprint</title>


<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">

<style>
body {
    margin: 0;
    font-family: 'Cairo', sans-serif;
    background: #f5f0e6; 
    color: #1b5e20;
   
}

/* ===== Navbar ===== */
.navbar {
    position: fixed;
    top: 0;
    width: 100%;
    background: #1b5e20;
    padding: 12px 15px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: white;
    z-index: 1000;
}

.logo-area {
    display: flex;
    align-items: center;
}

.logo-area img {
    width: 40px;
    margin-left: 10px;
}

.project-name {
    font-size: 20px;
    font-weight: bold;
}

.nav-links a {
    color: white;
    text-decoration: none;
    margin-left: 20px;
    font-size: 16px;
}

.nav-links a:hover {
    text-decoration: underline;
}

/* ===== Home Section ===== */
.hero {
    height: 100vh;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    margin-top: 60px;
    text-align: center;
    background-color: #f5f0e6;
    transition: background-color 0.3s ease;
}

.logo-img {
    width: 160px;
    margin-bottom: 20px;
    transition: transform 0.3s ease;
}

.title {
    font-size: 55px;
    font-weight: bold;
    transition: transform 0.3s ease;
}

.slogan {
    font-size: 22px;
    margin-top: 10px;
}

.description {
    margin-top: 15px;
    font-size: 18px;
    color: #2e7d32;
}

.start-btn {
    margin-top: 25px;
    padding: 12px 30px;
    font-size: 18px;
    background-color: #2e7d32;
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: background 0.3s, transform 0.3s;
}

.start-btn:hover {
    background-color: #1b5e20;
    transform: scale(1.05);
}

</style>
</head>

<body>

<!-- ===== Navbar ===== -->
<div class="navbar">

    <div class="logo-area">
        <img src="logo.png" alt="Logo">
        <div class="project-name">ZeroFootprint</div>
    </div>

    <div class="nav-links">
         <a href="contact.php">تواصل معنا </a>
        <a href="about.php">من نحن</a>
        <a href="login.php">تسجيل الدخول</a>
        <a href="register.php">إنشاء حساب</a>
    </div>
</div>

<!-- ===== Home ===== -->
<div class="hero">

    <img src="logo.png" alt="Logo" class="logo-img">

    <div class="title">ZeroFootprint</div>

    <div class="slogan">نحو مدينة مستقبلية مستدامة 🌱</div>

    <div class="description">
        منصة رقمية لقياس وتقليل البصمة الكربونية للأفراد
    </div>

    <button class="start-btn" onclick="window.location.href='login.php'">ابدأ الآن</button>

</div>

<!-- ===== Scroll Effect ===== -->
<script>
window.addEventListener('scroll', function() {
    const hero = document.querySelector('.hero');
    const title = document.querySelector('.title');
    const logo = document.querySelector('.logo-img');

    let scroll = window.scrollY;

   
    hero.style.backgroundColor = `rgba(46, 125, 50, ${Math.min(scroll / 600, 0.7)})`;

   
    title.style.transform = `translateY(${scroll * 0.2}px)`;
    logo.style.transform = `translateY(${scroll * 0.3}px)`;
});
</script>

</body>
</html>


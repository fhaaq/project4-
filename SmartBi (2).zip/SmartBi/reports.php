<?php
session_start();
include 'database.php';

// حماية الصفحة
if(!isset($_SESSION['role'])){
    header("Location: login.php");
    exit();
}

/* ================== جلب الطوابق ================== */
$floors = [];

$result = $conn->query("
    SELECT Floors.id, Floors.floor_number, Buildings.name as building_name
    FROM Floors
    JOIN Buildings ON Floors.building_id = Buildings.id
");

while($row = $result->fetch_assoc()){
    $floors[] = $row;
}

/* ================== الفلاتر ================== */
$selected_floors = $_GET['floors'] ?? [];
$from_date = $_GET['from_date'] ?? date('Y-m-01');
$to_date = $_GET['to_date'] ?? date('Y-m-d');

/* ================== الاستعلام ================== */
$where = "WHERE record_date BETWEEN '$from_date' AND '$to_date'";

if(!empty($selected_floors)){
    $ids = implode(',', array_map('intval', $selected_floors));
    $where .= " AND floor_id IN ($ids)";
}

/* ================== البيانات ================== */
$data = $conn->query("
SELECT 
    SUM(total_electricity) as total_elec,
    SUM(total_water) as total_water,
    AVG(avg_temperature) as avg_temp,
    AVG(avg_humidity) as avg_hum,
    AVG(avg_co2) as avg_co2
FROM Daily_Records
$where
")->fetch_assoc();

/* ================== الرسم ================== */
$chartLabels = [];
$chartData = [];

$res = $conn->query("
SELECT record_date, SUM(avg_co2) as co2
FROM Daily_Records
$where
GROUP BY record_date
ORDER BY record_date
");

while($row = $res->fetch_assoc()){
    $chartLabels[] = $row['record_date'];
    $chartData[] = $row['co2'];
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>التقارير — ZeroFootprint</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">

<style>
body{margin:0;font-family:'Cairo',sans-serif;direction:rtl;background:linear-gradient(#f5f0e6,#e8f5e9);}
.navbar{position:fixed;top:0;width:100%;background:#1b5e20;padding:12px 20px;display:flex;justify-content:space-between;align-items:center;color:white;z-index:1000;}
.project-name{font-size:22px;font-weight:bold;}
.nav-links{display:flex;gap:20px;}
.nav-links a{color:white;text-decoration:none;font-size:16px;}
.nav-links a:hover{text-decoration:underline;}
.container{margin-top:100px;padding:20px;}
.filter{margin-bottom:25px;display:flex;gap:15px;flex-wrap:wrap;align-items:center;}
.filter label{font-weight:bold;}
.checkbox-group{display:flex;gap:15px;flex-wrap:wrap;}
input[type=date]{padding:8px;border-radius:6px;border:1px solid #ccc;}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:20px;}
.card{background:white;padding:20px;border-radius:12px;box-shadow:0 5px 15px rgba(0,0,0,0.15);text-align:center;}
.card h3{margin-bottom:10px;color:#2e7d32;}
.chart{margin-top:30px;background:white;padding:25px;border-radius:12px;box-shadow:0 5px 15px rgba(0,0,0,0.15);max-width:500px;margin:auto;}
</style>
</head>

<body>

<div class="navbar">
    <div class="project-name">ZeroFootprint - مرحبا <?= $_SESSION['name'] ?></div>
    <div class="nav-links">
        <?php if($_SESSION['role'] === 'admin'): ?>
        <a href="dashboard.php">لوحة التحكم</a>
        <a href="settings.php">الإعدادات</a>
        <?php endif; ?>
        <a href="logout.php">تسجيل الخروج</a>
    </div>
</div>

<div class="container">
<h2>التقارير</h2>

<!-- ================== الفلاتر ================== -->
<form class="filter" method="GET">

<label>اختر الطوابق:</label>

<div class="checkbox-group">
<?php foreach($floors as $f): ?>
<label>
<input type="checkbox" name="floors[]" value="<?= $f['id'] ?>"
<?= in_array($f['id'],$selected_floors)?'checked':'' ?>>
<?= $f['building_name'] ?> - طابق <?= $f['floor_number'] ?>
</label>
<?php endforeach; ?>
</div>

<label>من تاريخ:</label>
<input type="date" name="from_date" value="<?= $from_date ?>">

<label>إلى تاريخ:</label>
<input type="date" name="to_date" value="<?= $to_date ?>">

<button>تطبيق</button>

</form>

<!-- ================== الكروت ================== -->
<div class="cards">
<div class="card"><h3>الكهرباء</h3><h2><?= round($data['total_elec'] ?? 0,1) ?></h2></div>
<div class="card"><h3>المياه</h3><h2><?= round($data['total_water'] ?? 0,1) ?></h2></div>
<div class="card"><h3>متوسط الحرارة</h3><h2><?= round($data['avg_temp'] ?? 0,1) ?>°C</h2></div>
<div class="card"><h3>متوسط الرطوبة</h3><h2><?= round($data['avg_hum'] ?? 0,1) ?>%</h2></div>
<div class="card"><h3>متوسط CO₂</h3><h2><?= round($data['avg_co2'] ?? 0,1) ?></h2></div>
</div>

<!-- ================== الرسم ================== -->
<div class="chart">
<h3>تغير CO₂ حسب الأيام</h3>
<canvas id="chart"></canvas>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
new Chart(document.getElementById('chart'), {
    type:'bar',
    data:{
        labels: <?= json_encode($chartLabels) ?>,
        datasets:[{
            label:'CO2',
            data: <?= json_encode($chartData) ?>,
            backgroundColor:'#2e7d32'
        }]
    }
});
</script>

</body>
</html>
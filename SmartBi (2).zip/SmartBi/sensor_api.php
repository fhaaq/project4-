<?php
include 'database.php';

$floor_id = $_GET['floor_id'];
$temp = $_GET['temp'];
$humidity = $_GET['humidity'];
$co2 = $_GET['co2'];

$today = date('Y-m-d');

$conn->query("
INSERT INTO Daily_Records (floor_id, avg_temperature, avg_humidity, avg_co2, record_date)
VALUES ($floor_id, $temp, $humidity, $co2, '$today')
ON DUPLICATE KEY UPDATE
avg_temperature = $temp,
avg_humidity = $humidity,
avg_co2 = $co2
");
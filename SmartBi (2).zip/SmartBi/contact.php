<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>تواصل معنا</title>

<!-- خط عربي Cairo -->
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">

<style>
body {
    margin: 0;
    font-family: 'Cairo', sans-serif;
    direction: rtl;
    background: linear-gradient(#f5f0e6, #e8f5e9);
    color: #1b5e20;
    display: flex;
    flex-direction: column;
    align-items: center;
}

/* ===== Navbar ===== */
.navbar {
    position: fixed;
    top: 0;
    width: 100%;
    background: #1b5e20;
    padding: 12px 15px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: white;
    z-index: 1000;
}

.logo-area {
    display: flex;
    align-items: center;
}

.logo-area img {
    width: 40px;
    margin-left: 10px;
}

.project-name {
    font-size: 20px;
    font-weight: bold;
}

.nav-links {
    display: flex;
    gap: 25px;
}

.nav-links a {
    color: white;
    text-decoration: none;
    font-size: 16px;
    white-space: nowrap;
}

.nav-links a:hover {
    text-decoration: underline;
}

/* ===== Contact Form (مطابق لصندوق تسجيل الدخول) ===== */
.contact-container {
    margin-top: 100px; /* لتكون أسفل Navbar */
    background-color: rgba(255,255,255,0.85); /* نفس الشفافية واللون للبوكس */
    padding: 40px;
    border-radius: 12px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    width: 350px; /* نفس حجم نموذج تسجيل الدخول */
}

.contact-container h2 {
    text-align: center;
    margin-bottom: 25px;
}

.contact-container input,
.contact-container textarea {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border-radius: 6px;
    border: 1px solid #ccc;
    font-size: 16px;
}

.contact-container button {
    width: 100%;
    padding: 12px;
    background-color: #2e7d32;
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 18px;
    cursor: pointer;
    transition: background 0.3s;
}

.contact-container button:hover {
    background-color: #1b5e20;
}
</style>
</head>

<body>

<!-- ===== Navbar ===== -->
<div class="navbar">
    <div class="logo-area">
        <img src="logo.png" alt="Logo">
        <div class="project-name">ZeroFootprint</div>
    </div>

    <div class="nav-links">
        <a href="home.php">الرئيسية</a>
        <a href="about.php">من نحن</a>
        <a href="login.php">تسجيل الدخول</a>
        <a href="register.php">إنشاء حساب</a>
    </div>
</div>

<!-- ===== Contact Form ===== -->
<div class="contact-container">
    <h2>تواصل معنا</h2>
    <form action="send_message.php" method="post">
        <input type="text" name="name" placeholder="الاسم الكامل" required>
        <input type="email" name="email" placeholder="البريد الإلكتروني" required>
        <input type="text" name="subject" placeholder="الموضوع" required>
        <textarea name="message" placeholder="رسالتك..." rows="5" required></textarea>
        <button type="submit">إرسال</button>
    </form>
</div>

</body>
</html>
<?php
session_start();
include 'database.php';

// تحقق من تسجيل الدخول
if(!isset($_SESSION['email']) || $_SESSION['role'] !== 'admin'){
    header("Location: login.php");
    exit();
}

$userName = $_SESSION['name'] ?? "المسؤول";

/* ================== جلب المباني ================== */
$buildings = [];
$res = $conn->query("SELECT * FROM Buildings");

while($row = $res->fetch_assoc()){
    $buildings[] = $row;
}

/* ================== حفظ البيانات ================== */
$messages = [];

if(isset($_POST['submit_floor'])){
    $floor_id = intval($_POST['floor_id']);
    $electricity = floatval($_POST['electricity']);
    $people = intval($_POST['people']);
    $temperature = floatval($_POST['temperature']);
    $humidity = floatval($_POST['humidity']);
    $water = floatval($_POST['water']);

    $today = date('Y-m-d');

    // حساب CO2 (تقريبي)
    $co2 = ($electricity * 0.5) + ($water * 0.0003);

    // تحقق هل فيه سجل لنفس اليوم
    $check = $conn->query("
        SELECT id FROM Daily_Records 
        WHERE floor_id = $floor_id AND record_date = '$today'
    ");

    if($check->num_rows > 0){

        // تحديث
        $conn->query("
            UPDATE Daily_Records SET
            total_electricity = $electricity,
            total_water = $water,
            avg_temperature = $temperature,
            avg_humidity = $humidity,
            avg_co2 = $co2
            WHERE floor_id = $floor_id AND record_date = '$today'
        ");

        $messages[] = "تم تحديث البيانات بنجاح 🔄";

    } else {

        // إدخال
        $conn->query("
            INSERT INTO Daily_Records 
            (floor_id, total_electricity, total_water, avg_temperature, avg_humidity, avg_co2, record_date)
            VALUES 
            ($floor_id, $electricity, $water, $temperature, $humidity, $co2, '$today')
        ");

        $messages[] = "تم حفظ البيانات بنجاح ✅";
    }
}
?>
<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>إدخال البيانات اليدوية — ZeroFootprint</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">

<style>
body {
    margin:0;
    font-family:'Cairo',sans-serif;
    direction:rtl;
    background:linear-gradient(#f5f0e6,#e8f5e9);
}

/* Navbar */
.navbar{
    position:fixed;
    top:0;
    width:100%;
    background:#1b5e20;
    padding:12px 20px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    color:white;
    z-index:1000;
}
.project-name{font-size:22px;font-weight:bold;}
.nav-links{
    display:flex;
    gap:20px;
}
.nav-links a{color:white;text-decoration:none;font-size:16px;}
.nav-links a:hover{text-decoration:underline;}

/* Container */
.container{
    margin-top:130px;
    padding:20px;
    max-width:900px;
    margin:auto;
}

/* Floor Form Card */
.floor-card{
    background:white;
    padding:20px;
    border-radius:12px;
    box-shadow:0 5px 15px rgba(0,0,0,0.15);
    margin-bottom:20px;
}
.floor-card h3{color:#2e7d32;margin-bottom:10px;}
.floor-card input{
    width:100%;
    padding:8px;
    margin:5px 0;
    border-radius:6px;
    border:1px solid #ccc;
}
.floor-card button{
    padding:10px;
    width:100%;
    background:#2e7d32;
    color:white;
    border:none;
    border-radius:6px;
    cursor:pointer;
}
.floor-card button:hover{background:#1b5e20;}

/* Messages */
.messages{
    margin-bottom:15px;
    padding:10px;
    background:#c8e6c9;
    border:1px solid #2e7d32;
    border-radius:6px;
}
</style>
</head>
<body>

<!-- Navbar -->
<div class="navbar">
    <div class="project-name">ZeroFootprint - مرحباً، <?= htmlspecialchars($userName) ?></div>
    <div class="nav-links">
        <a href="dashboard.php">لوحة التحكم</a>
        <a href="manage_buildings.php">ادارة المباني</a>
        <a href="reports.php">التقارير</a>
        <a href="logout.php">تسجيل الخروج</a>
    </div>
</div>

<div class="container">
<h2>إدخال البيانات اليدوية</h2>

<?php foreach($messages as $msg): ?>
<div class="messages"><?= $msg ?></div>
<?php endforeach; ?>

<?php foreach($buildings as $b): ?>

<?php
$floors = $conn->query("SELECT * FROM Floors WHERE building_id = {$b['id']}");
?>

<?php while($f = $floors->fetch_assoc()): ?>

<?php
$today = date('Y-m-d');
$existing = $conn->query("
SELECT * FROM Daily_Records 
WHERE floor_id = {$f['id']} AND record_date = '$today'
")->fetch_assoc();
?>

<div class="floor-card">

<h3><?= htmlspecialchars($b['name']) ?> - الطابق <?= $f['floor_number'] ?></h3>

<form method="POST">
<input type="hidden" name="floor_id" value="<?= $f['id'] ?>">

<input type="number" name="electricity" value="<?= $existing['total_electricity'] ?? '' ?>" placeholder="الكهرباء (kWh)" step="0.01" required>

<input type="number" name="people" value="<?= $existing['avg_co2'] ?? '' ?>" placeholder="عدد الأشخاص" required>

<input type="number" name="temperature" value="<?= $existing['avg_temperature'] ?? '' ?>" placeholder="درجة الحرارة" step="0.1" required>

<input type="number" name="humidity" value="<?= $existing['avg_humidity'] ?? '' ?>" placeholder="الرطوبة" step="0.1" required>

<input type="number" name="water" value="<?= $existing['total_water'] ?? '' ?>" placeholder="المياه" step="0.01" required>

<button type="submit" name="submit_floor">حفظ بيانات الطابق</button>
</form>

</div>

<?php endwhile; ?>
<?php endforeach; ?>

</div>
</body>
</html>
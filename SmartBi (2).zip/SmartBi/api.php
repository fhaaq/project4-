<?php
include 'database.php';

// استقبال البيانات
$temp = $_POST['temp'];
$humidity = $_POST['humidity'];
$co2 = $_POST['co2'];
$floor_id = $_POST['floor_id'];

$today = date('Y-m-d');

// تحقق هل فيه سجل اليوم
$check = $conn->query("
    SELECT id FROM Daily_Records 
    WHERE floor_id = $floor_id AND record_date = '$today'
");

if($check->num_rows > 0){
    $conn->query("
        UPDATE Daily_Records SET
        avg_temperature = $temp,
        avg_humidity = $humidity,
        avg_co2 = $co2
        WHERE floor_id = $floor_id AND record_date = '$today'
    ");
} else {
    $conn->query("
        INSERT INTO Daily_Records 
        (floor_id, avg_temperature, avg_humidity, avg_co2, record_date)
        VALUES ($floor_id, $temp, $humidity, $co2, '$today')
    ");
}

echo "OK";
?>